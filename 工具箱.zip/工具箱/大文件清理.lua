require"import"
import"imports"
import"对话框"
function onKeyDown(code,event)
  if code==4 then
    if bjbj and bjbj.getVisibility()==0 then
      关闭文件详情布局()
    else
      this.finish()
    end
  return true
  end
end
task(2,function()
this.setContentView(loadlayout({
  FrameLayout,
  id="fbj",
  {
  LinearLayout,
  layout_width=w,
  layout_height=h,
  orientation="vertical",
  backgroundColor=0xFF9AAEC7,
  {
    LinearLayout,
    layout_width=w,
    layout_height="56dp",
    orientation="horizontal",
    layout_marginTop=getStatusBarHeight(),
    backgroundColor=0xFF9AAEC7,
    {
      ImageView,
      padding="17dp",
      layout_width="56dp",
      layout_height="56dp",
      ColorFilter=0xffffffff,
      layout_gravity="center",
      src="http://shp.qpic.cn/collector/2530648358/6ce8ce2c-f0ac-4c11-b6c1-2c7daf86ac60/0",
      onClick=function()
        this.finish()
      end,
    },
    {
      TextView,
      id="dwjqlbt",
      textSize="18dp",
      text="大文件清理",
      layout_weight="1",
      textColor=0xffffffff,
      paddingLeft="17dp",
      layout_gravity="center",
    },
    {
      ImageView,
      id="qxhdwjqlqx",
      padding="17dp",
      layout_width="56dp",
      layout_height="56dp",
      ColorFilter=0xffffffff,
      layout_gravity="center",
      src="http://shp.qpic.cn/collector/2530648358/b1f989b5-646a-459f-88f3-dd03ffedfa59/0",
      onClick=function()
        if 待删除文件路径 then
          if 全选 then
            全选=nil
            for i=1,#待删除文件路径 do
              待删除文件路径[i]=false
              dwjlb.getChildAt(i-1).getChildAt(0).getChildAt(0).getChildAt(2).setChecked(false)
            end
            qxhdwjqlqx.setImageBitmap(loadbitmap('http://shp.qpic.cn/collector/2530648358/b1f989b5-646a-459f-88f3-dd03ffedfa59/0'))
            dwjqlbt.text="大文件清理"
          else
            全选=true
            for i=1,#待删除文件路径 do
              待删除文件路径[i]=true
              dwjlb.getChildAt(i-1).getChildAt(0).getChildAt(0).getChildAt(2).setChecked(true)
            end
            qxhdwjqlqx.setImageBitmap(loadbitmap('http://shp.qpic.cn/collector/2530648358/17ef4ca4-70b8-4288-ace7-b965b13caa89/0'))
            dwjqlbt.text="大文件清理("..#待删除文件路径..")"
          end
        end
      end,
    },
  },
  {
    FrameLayout,
    layout_width=w,
    backgroundColor=0xFFFFFFFF,
    layout_height=h-getStatusBarHeight()-56*scale,
    {
      LinearLayout,
      layout_width=w,
      layout_height="fill",
      orientation="vertical",
      {
        LinearLayout,
        layout_width=w,
        gravity="center|bottom",
        layout_height=(h-getStatusBarHeight()-72*scale)/2,
        {
          ProgressBar,
          id="pgb",
        },
      },
      {
        TextView,
        id="wjljwb",
        paddingLeft="16dp",
        paddingRight="16dp",
        layout_gravity="center",
        textColor=0xFF6E6E6E,
        layout_marginTop="16dp",
        layout_height=(h-getStatusBarHeight()-72*scale)/2,
      },
    },
    {
      NestedScrollView,
      id="dwjlbbjbj",
      visibility=4,
      layout_width=w,
      layout_height=h-getStatusBarHeight()-56*scale,
      backgroundColor=0xFFFAFAFA,
      {
        LinearLayout,
        id="dwjlb",
        orientation="vertical",
      },
    },
    {
      CardView,
      visibility=4,
      id="dwjqlan",
      radius="28dp",
      elevation="5dp",
      layout_width="56dp",
      layout_height="56dp",
      layout_margin="16dp",
      layout_gravity="right|bottom",
      layout_marginBottom=16*scale,
      cardBackgroundColor=0xFF68AFE5,
      {
        ImageView,
        padding="16dp",
        layout_width="fill",
        layout_height="fill",
        ColorFilter=0xffffffff,
        layout_gravity="center",
        src="http://shp.qpic.cn/collector/2530648358/c5794b00-8e26-4e15-88cf-008d722098cd/0",
        onClick=function()
          n=0
          for i=1,#待删除文件路径 do
            if 待删除文件路径[i]==true then
              n=n+1
            end
          end
          if n==0 then
            提示"无文件可清理"
          else
            对话框()
            .设置标题("警示！")
            .设置消息("确定要删除所选文件吗？删除后将不能恢复。")
            .设置中立按钮("取消")
            .设置积极按钮("确定",function()
              共清理文件大小=0.00
              for i=#待删除文件路径,1,-1 do
                if 待删除文件路径[i]==true then
                  local f=io.open(tostring(大文件列表[i]),'r')
                  if f then
                    io.close(f)
                    共清理文件大小=共清理文件大小+File(tostring(大文件列表[i])).length()
                    os.remove(tostring(大文件列表[i]))
                  end
                  table.remove(大文件列表,i)
                end
                dwjlb.removeView(dwjlb.getChildAt(i-1))
              end
              dwjqlbt.text="大文件清理"
              查找完成(大文件列表)
              if 共清理文件大小>0 then
                共清理文件大小=string.format("%.2f",共清理文件大小/1048576)
              end
              task(5,function()
                对话框()
                .设置标题("提示")
                .设置消息("清理完成,共清理了"..共清理文件大小.."MB。")
                .设置积极按钮("确定")
                .显示()
              end)
            end)
            .显示()
          end
        end,
      },
    },
  },
  },
}))
pgb.IndeterminateDrawable.setColorFilter(PorterDuffColorFilter(0xFF68AFE5,PorterDuff.Mode.SRC_ATOP))
function 显示文件路径(str)
  wjljwb.text=str
end
function 文件详情(path)
fbj.addView(loadlayout({
  LinearLayout,
  id="bjbj",
  layout_width=w,
  layout_height=h,
  backgroundColor=0x80000000,
  {
    CardView,
    id="bjkp",
    radius="10dp",
    layout_width=w,
    layout_gravity="bottom",
    layout_marginBottom="-10dp",
    cardBackgroundColor=0xFFFFFFFF,
    {
      LinearLayout,
      layout_width=w,
      orientation="vertical",
      {
        LinearLayout,
        layout_width=w,
        paddingTop="24dp",
        paddingLeft="32dp",
        paddingRight="24dp",
        orientation="horizontal",
        {
          ImageView,
          layout_width="24dp",
          layout_height="24dp",
          layout_gravity="center",
          ColorFilter=0xFF9AAEC7,
          src="http://shp.qpic.cn/collector/2530648358/a23fee1a-c303-4666-a45c-1fbbe9d9e58f/0"
        },
        {
          TextView,
          textSize="17sp",
          text="文件详情",
          layout_weight="1",
          layout_gravity="center",
          textColor=0xFF000000,
          layout_marginLeft="16dp",
          Typeface=Typeface.DEFAULT_BOLD,
        },
        {
          ImageView,
          id="gbwjxqbj",
          padding="15dp",
          layout_width="55dp",
          layout_height="55dp",
          layout_gravity="center",
          ColorFilter=0xFF707070,
          src="http://shp.qpic.cn/collector/2530648358/6a4d61ec-a43b-454e-87c7-3a471e95e51a/0",
          onClick=function()
            关闭文件详情布局()
          end,
        },
      },
      {
        LinearLayout,
        paddingLeft="56dp",
        paddingRight="40dp",
        orientation="vertical",
        paddingBottom="10dp",
        {
          TextView,
          text="文件名称",
          textSize="16sp",
          paddingTop="16dp",
          textColor=0xFF68AFE5,
        },
        {
          TextView,
          paddingTop="8dp",
          paddingLeft="8dp",
          textIsSelectable=true,
          paddingBottom="16dp",
          textColor=0xFF6E6E6E,
          text=File(tostring(path)).getName(),
        },
        {
          TextView,
          text="文件路径",
          textSize="16sp",
          paddingTop="16dp",
          textColor=0xFF68AFE5,
        },
        {
          TextView,
          paddingTop="8dp",
          paddingLeft="8dp",
          text=tostring(path),
          textIsSelectable=true,
          paddingBottom="16dp",
          textColor=0xFF6E6E6E,
        },
        {
          TextView,
          text="MD5",
          textSize="16sp",
          paddingTop="16dp",
          textColor=0xFF68AFE5,
        },
        {
          TextView,
          id="md5wb",
          text="获取中..",
          paddingTop="8dp",
          paddingLeft="8dp",
          textIsSelectable=true,
          paddingBottom="32dp",
          textColor=0xFF6E6E6E,
        },
      },
    },
  },
}))
波纹(gbwjxqbj,0xFFE2E2E2)
位移动画(bjkp,200,0,0,geth(bjkp),0)
function 设置md5文本(md5)
  md5wb.text=md5
end
thread(获取文件md5,tostring(path),"设置md5文本")
function 关闭文件详情布局()
  位移动画(bjkp,200,0,0,0,geth(bjkp),function()
    bjbj.setVisibility(8)
  end)
end
bjkpsety=0
bjbj.onTouch=function(v,e)
  a=e.getAction()&255
  if a==MotionEvent.ACTION_DOWN then
    if e.getY()>=h-geth(bjkp) then
      csdjwz=e.getY()
    else
      csdjwz=h+1
    end
  elseif a==MotionEvent.ACTION_MOVE then
    if csdjwz==h+1 then
    elseif csdjwz>e.getY() then
      csdjwz=e.getY()
    else
      bjkpsety=h-geth(bjkp)+e.getY()-csdjwz+10*scale
      bjkp.setY(bjkpsety)
    end
  elseif a==MotionEvent.ACTION_UP then
    if csdjwz==h+1 then
      关闭文件详情布局()
    elseif bjkpsety>=h-0.5*geth(bjkp) then
      关闭文件详情布局()
    else
      bjkp.setY(h-geth(bjkp)+10*scale)
      位移动画(bjkp,150,0,0,bjkpsety-(h-geth(bjkp)+10*scale),0)
    end
  end
  return true
end
end
function 添加布局(path,i)
  if i%2==1 then
    color=0xffffffff
  else
    color=0xfff8f8f8
  end
  if tostring(File(tostring(path)).getParentFile()):match("/storage/emulated/0(.+)")==nil then
    文件父路径="来自sdcard根目录"
  else
    文件父路径=tostring(File(tostring(path)).getParentFile()):match("/storage/emulated/0(.+)")
  end
  if File(tostring(path)).length()>=1073741824 then
    单位="G"
    dwbjys=0xFFEC534B
    文件大小=string.format("%.1f",File(tostring(path)).length()/1073741824)
  else
    单位="M"
    dwbjys=0xFF68AFE5
    文件大小=string.format("%.1f",File(tostring(path)).length()/1048576)
  end
  布局={
    LinearLayout,
    backgroundColor=color,
    {
      LinearLayout,
      layout_width=w,
      id="大文件列表"..i,
      orientation="vertical",
      onClick=function()
        if loadstring("return fxk"..i)().isChecked()==false then
          loadstring("return fxk"..i)().setChecked(true)
          待删除文件路径[i]=true
         else
          loadstring("return fxk"..i)().setChecked(false)
          待删除文件路径[i]=false
        end
        n=0
        for i=1,#待删除文件路径 do
          if 待删除文件路径[i]==true then
            n=n+1
          end
        end
        if n>0 then
          dwjqlbt.text="大文件清理("..n..")"
         else
          dwjqlbt.text="大文件清理"
        end
      end,
      {
        LinearLayout,
        layout_width=w,
        paddingTop="17dp",
        paddingLeft="17dp",
        paddingRight="17dp",
        orientation="horizontal",
        {
          FrameLayout,
          layout_width="50dp",
          layout_height="50dp",
          {
            CardView,
            elevation=0,
            radius="25dp",
            layout_width="50dp",
            layout_height="50dp",
            cardBackgroundColor=0xFF9AAEC7,
            {
              TextView,
              textSize="14sp",
              text=文件大小,
              layout_gravity="center",
              textColor=0xFFFFFFFF,
            },
          },
          {
            CardView,
            elevation=0,
            radius="9dp",
            layout_width="18dp",
            layout_height="18dp",
            layout_gravity="right|bottom",
            cardBackgroundColor=dwbjys,
            {
              TextView,
              text=单位,
              textSize="10sp",
              textColor=0xFFFFFFFF,
              layout_gravity="center",
              Typeface=Typeface.DEFAULT_BOLD,
            },
          },
        },
        {
          LinearLayout,
          layout_weight="1",
          paddingLeft="17dp",
          paddingRight="17dp",
          orientation="vertical",
          layout_gravity="center",
          {
            TextView,
            text=tostring(path.name),
            textSize="16sp",
            textColor=0xFF000000,
          },
          {
            TextView,
            maxLines=1,
            ellipsize="start",
            text=文件父路径,
            textColor=0xFF6E6E6E,
          },
        },
        {
          CheckBox,
          id="fxk"..i,
          layout_gravity="center",
          onClick=function()
            if loadstring("return fxk"..i)().isChecked()==true then
              待删除文件路径[i]=true
             else
              待删除文件路径[i]=false
            end
            n=0
            for i=1,#待删除文件路径 do
              if 待删除文件路径[i]==true then
                n=n+1
              end
            end
            if n>0 then
              dwjqlbt.text="大文件清理("..n..")"
             else
              dwjqlbt.text="大文件清理"
            end
          end,
        },
      },
      {
        TextView,
        padding="7dp",
        id="文件详情"..i,
        text="文件详情",
        layout_gravity="right",
        textColor=0xFF68AFE5,
        layout_marginBottom="8dp",
        layout_marginRight="17.5dp",
        onClick=function()
          文件详情(path)
        end,
      },
    },
  }
  return 布局
end
function 查找完成(ret)
  大文件列表={}
  待删除文件路径={}
  dwjlbbjbj.setVisibility(0)
  for i=1,#ret do
    大文件列表[i]=ret[i]
    待删除文件路径[i]=false
    dwjlb.addView(loadlayout(添加布局(ret[i],i)))
    波纹方(dwjlb.getChildAt(i-1).getChildAt(0),0xFFE9E9E9)
    波纹方(dwjlb.getChildAt(i-1).getChildAt(0).getChildAt(1),0xFFE9E9E9)
  end
  dwjqlan.setVisibility(0)
  dwjlbbjbj.setOnScrollChangeListener(NestedScrollView.OnScrollChangeListener{
    onScrollChange=function(v,nowx,nowy,oldx,oldy)
      if nowy>oldy then
        if dwjqlan.getVisibility()==0 then
          缩放动画(dwjqlan,300,1,0,1,0,相对自身,0.5,相对自身,0.5,function()
            dwjqlan.setVisibility(8)
          end)
        end
      else
        if dwjqlan.getVisibility()==8 then
          dwjqlan.setVisibility(0)
          缩放动画(dwjqlan,300,0,1,0,1,相对自身,0.5,相对自身,0.5)
        end
      end
    end
  })
  collectgarbage("collect")
end
thread(function()
  local ret={}
  require "import"
  import "java.io.File"
  import "java.lang.String"
  function FindFile(catalog)
  local ls=catalog.listFiles() or File{}
    for 次数=0,#ls-1 do
      if 次数==tointeger(#ls/4) or 次数==tointeger(#ls/2) or 次数==tointeger(#ls*0.75) then
        collectgarbage("collect")
      end
      local f=ls[次数]
      if f.isDirectory() then
        call("显示文件路径",tostring(f))
        FindFile(f)
      else
        if File(tostring(f)).length()>=31457280 then
          table.insert(ret,f)
        end
      end
    end
  end
  FindFile(File("/storage/emulated/0/"))
  call("查找完成",ret)
  luajava.clear(f)
  collectgarbage("collect")
end)
end)