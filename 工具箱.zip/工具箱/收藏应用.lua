require"import"
import"imports"
需添加收藏应用=...
task(2,function()
工具箱主页待添加收藏应用=""
activity.setContentView(loadlayout({
  LinearLayout,
  layout_width=w,
  layout_height=h,
  orientation="vertical",
  backgroundColor=0xffffffff,
  {
    FrameLayout,
    layout_width=w,
    layout_height=h,
    {
      LinearLayout,
      layout_width=w,
      elevation="5dp",
      backgroundColor=0xFF9AAEC7,
      layout_height=getStatusBarHeight()+64*scale,
      {
        LinearLayout,
        layout_width=w,
        layout_gravity="bottom",
        orientation="horizontal",
        layout_height=64*scale,
        {
          ImageView,
          padding="20dp",
          layout_width="64dp",
          layout_height="64dp",
          ColorFilter=0xffffffff,
          layout_gravity="center",
          src="http://shp.qpic.cn/collector/2530648358/6ce8ce2c-f0ac-4c11-b6c1-2c7daf86ac60/0",
          onClick=function()activity.finish()end,
        },
        {
          TextView,
          text="添加收藏",
          textSize="20dp",
          layout_weight="1",
          textColor=0xffffffff,
          layout_gravity="center",
          backgroundColor=0xFF9AAEC7,
        },
        {
          ImageView,
          padding="20dp",
          layout_width="64dp",
          ColorFilter=0xffffffff,
          layout_height="64dp",
          layout_gravity="center",
          onClick=function()activity.finish()end,
          src="http://shp.qpic.cn/collector/2530648358/17ef4ca4-70b8-4288-ace7-b965b13caa89/0",
        },
      },
    },
    {
      NestedScrollView,
      layout_width="fill",
      layout_height="fill",
      layout_marginTop=40/32*64*scale+getStatusBarHeight(),
      layout_marginLeft="8dp",
      layout_marginRight="8dp",
      {
        LinearLayout,
        layout_width="fill",
        layout_height="fill",
        orientation="horizontal",
        {
          LinearLayout,
          id="yysczl",
          orientation="vertical",
          layout_width=0.5*w-32*scale/4,
        },
        {
          LinearLayout,
          id="yyscyl",
          orientation="vertical",
          layout_width=0.5*w-32*scale/4,
        },
      },
    },
    {
      CardView,
      radius="28dp",
      elevation="5dp",
      layout_width="56dp",
      layout_height="56dp",
      layout_margin="16dp",
      layout_gravity="right|bottom",
      cardBackgroundColor=0xFF68AFE5,
      {
        ImageView,
        padding="14dp",
        layout_width="fill",
        layout_height="fill",
        ColorFilter=0xffffffff,
        layout_gravity="center",
        src="http://shp.qpic.cn/collector/2530648358/63f0b437-8922-485c-8f85-8c2077fca763/0",
        onClick=function()
          if 工具箱主页待添加收藏应用=="" then
            提示"未添加。"
          else
            工具箱主页收藏应用=io.open("/data/data/"..activity.getPackageName().."/工具箱主页收藏应用"):read("*a")
            io.open("/data/data/"..activity.getPackageName().."/工具箱主页收藏应用","w+"):write(工具箱主页收藏应用:sub(1,#工具箱主页收藏应用-1)..工具箱主页待添加收藏应用.."}"):close()
            提示"添加收藏成功。"
            activity.finish()
          end
        end,
      },
    },
  },
}))
function 添加布局(名称,已勾选,可勾选)
布局={
  LinearLayout,
  layout_width="fill",
  {
    CardView,
    elevation=0,
    radius="4dp",
    layout_width="fill",
    layout_margin="8dp",
    cardBackgroundColor=0xFFF8F8F8,
    {
      LinearLayout,
      id=名称:gsub(" ",""),
      padding="8dp",
      layout_width="fill",
      orientation="horizontal",
      onClick=function()
        if 可勾选==true then
          if loadstring("return "..名称:gsub(" ","").."fxk")().isChecked()==false then
            loadstring("return "..名称:gsub(" ","").."fxk")().setChecked(true)
            工具箱主页待添加收藏应用=工具箱主页待添加收藏应用..'"'..名称..'",'
          else
            loadstring("return "..名称:gsub(" ","").."fxk")().setChecked(false)
            工具箱主页待添加收藏应用=工具箱主页待添加收藏应用:gsub('"'..名称..'",',"")
          end
        end
      end,
      {
        TextView,
        gravity="center",
        text=名称,
        layout_weight="1",
        layout_gravity="center",
        textColor=0xFF424242,
      },
      {
        CheckBox,
        id=名称:gsub(" ","").."fxk",
        checked=已勾选,
        enabled=可勾选,
        layout_gravity="center",
        onClick=function()
          if 已添加==nil then
            if loadstring("return "..名称:gsub(" ","").."fxk")().isChecked()==true then
              工具箱主页待添加收藏应用=工具箱主页待添加收藏应用..'"'..名称..'",'
            else
              工具箱主页待添加收藏应用=工具箱主页待添加收藏应用:gsub('"'..名称:gsub(" ","")..'",',"")
            end
          end
        end,
      },
    },
  },
}
return 布局
end
应用列表=loadstring("return "..io.open(this.getLuaDir().."/应用列表"):read("*a"))()
已添加收藏应用=loadstring("return "..io.open("/data/data/"..activity.getPackageName().."/工具箱主页收藏应用"):read("*a"))()
for i=1,#应用列表 do
  for n=1,#已添加收藏应用+1 do
    if n==#已添加收藏应用+1 then
      可勾选=true
      已勾选=false
    elseif 应用列表[i]==已添加收藏应用[n] then
      可勾选=false
      已勾选=true
      break
    end
  end
  if 应用列表[i]==需添加收藏应用 then
    已勾选=true
    工具箱主页待添加收藏应用=工具箱主页待添加收藏应用..'"'..应用列表[i]..'",'
  end
  if i%2==1 then
    yysczl.addView(loadlayout(添加布局(应用列表[i],已勾选,可勾选)))
  else
    yyscyl.addView(loadlayout(添加布局(应用列表[i],已勾选,可勾选)))
  end
  波纹(loadstring("return "..应用列表[i]:gsub(" ",""))(),0xFFE9E9E9)
  loadstring("return "..应用列表[i]:gsub(" ",""))().onLongClick=function()
    activity.finish()
  end
end
end)