import "android.view.MotionEvent"
import "android.view.inputmethod.InputMethodManager"
import "android.view.Gravity"
import "android.widget.Toast"
import "android.app.ActionBar"
import 'android.graphics.*'
import "android.widget.*"
import "android.support.v7.widget.CardView"
import"android.support.v4.widget.*"
import "android.widget.RelativeLayout"
import "android.support.v4.widget.DrawerLayout"
import "android.net.ConnectivityManager"
import "com.androlua.LuaUtil"
import "java.io.FileOutputStream"
import "android.graphics.Bitmap"
import "android.graphics.PorterDuffColorFilter"
import "android.graphics.PorterDuff"
import "android.provider.Settings"
import "android.graphics.drawable.BitmapDrawable"
import "android.content.res.ColorStateList"
import "android.content.pm.PackageInfo"
import "android.support.v4.widget.SwipeRefreshLayout"
import "android.content.pm.PackageManager"
import "java.io.ByteArrayInputStream"
import "java.security.cert.CertificateFactory"
import "java.security.MessageDigest"
import "java.lang.String"
import "java.io.File"
import "android.os.Environment"
import "android.os.Build"
import "android.provider.Settings$Secure"
import "android.os.StatFs"
import "android.text.format.Formatter"
import "android.view.ViewAnimationUtils"
import "android.view.animation.AlphaAnimation"
import "android.content.Intent"
import "android.net.Uri"
import "android.view.WindowManager"
import "android.view.View"
import "android.graphics.Color"
import "android.content.Context"
import "android.webkit.MimeTypeMap"
import "android.content.pm.ApplicationInfo"
import "android.telephony.TelephonyManager"
import "android.view.animation.*"
import "android.view.animation.Animation$AnimationListener"
相对自身=Animation.RELATIVE_TO_SELF
相对父控件=Animation.RELATIVE_TO_PARENT
绝对=Animation.ABSOLUTE
w=activity.getWidth()
h=activity.getHeight()
activity.setContentView(loadlayout({
LinearLayout,
layout_width="10dp",
layout_height="10dp",
{
  LinearLayout,
  id="pmbl",
  layout_width="1dp",
}
}))
task(1,function ()
scale=pmbl.getWidth()
end)
window=activity.getWindow()
window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
window.setStatusBarColor(0x0)
function getStatusBarHeight(JDPUK)
  if not tostring(jdpuk)==string.byte("")..string.byte("")..string.byte("4")..string.char(55).."32" then error()end
  local resid=activity.getResources().getIdentifier("status_bar_height","dimen","android")
  if resid>0 then
    return activity.getResources().getDimensionPixelSize(resid)
  end
end
function getw(view)
view.measure(View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED),View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED));
width=view.getMeasuredWidth()
return width
end
function geth(view)
view.measure(View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED),View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED));
height=view.getMeasuredHeight()
return height
end
function seth(view,h)
linearParams=view.getLayoutParams()
linearParams.height=h
view.setLayoutParams(linearParams)
end
function setw(view,w)
linearParams=view.getLayoutParams()
linearParams.width=w
view.setLayoutParams(linearParams)
end
function 颜色(id,color)
  import 'android.graphics.*'
  local mEditorField = TextView.getDeclaredField('mEditor')
  mEditorField.setAccessible(true)
  local mEditor = mEditorField.get(id)
  local field = Editor.getDeclaredField('mCursorDrawable')
  field.setAccessible(true)
  local mCursorDrawable = field.get(mEditor)
  local mccdf = TextView.getDeclaredField('mCursorDrawableRes')
  mccdf.setAccessible(true)
  local mccd = activity.getResources().getDrawable(mccdf.getInt(id))
  mccd.setColorFilter(PorterDuffColorFilter(color,PorterDuff.Mode.SRC_ATOP))
  mCursorDrawable[0] = mccd
  mCursorDrawable[1] = mccd
end
function 波纹(id,颜色)
  import "android.content.res.ColorStateList"
  local attrsArray = {android.R.attr.selectableItemBackgroundBorderless} 
  local typedArray =activity.obtainStyledAttributes(attrsArray) 
  ripple=typedArray.getResourceId(0,0) 
  Pretend=activity.Resources.getDrawable(ripple) 
  Pretend.setColor(ColorStateList(int[0].class{int{}},int{颜色}))
  id.setBackground(Pretend.setColor(ColorStateList(int[0].class{int{}},int{颜色})))
end
function 波纹方(id,color)
  ripples=activity.obtainStyledAttributes({android.R.attr.selectableItemBackground}).getResourceId(0,0)
  id.setBackgroundDrawable(activity.Resources.getDrawable(ripples).setColor(ColorStateList(int[0].class{int{}},int{color})))
end
function 提示(t)
  local tsbj={
    LinearLayout,
    {
      CardView,
      radius="4dp",
      Elevation="8dp",
      layout_margin="8dp",
      CardBackgroundColor=0xff202124,
      {
        LinearLayout,
        padding="16dp",
        layout_width=w-16*scale,
        {
          TextView,
          Text=tostring(t),
          textSize="14sp",
          paddingLeft="8dp",
          paddingRight="8dp",
          textColor=0xffffffff,
        },
      },
    },
  }
  if toast then
    toast.cancel()
    toast=nil
  end
  toast=Toast.makeText(activity,"",Toast.LENGTH_SHORT).setGravity(Gravity.BOTTOM|Gravity.CENTER, 0, 0).setView(loadlayout(tsbj))
  toast.show()
end
function 位移动画(id,时间,开始x,结束x,开始y,结束y,动画结束)
  local 动画=TranslateAnimation(开始x, 结束x,开始y, 结束y).setDuration(时间)
  id.startAnimation(动画)
  if 动画结束 then
    动画.setAnimationListener(AnimationListener{
      onAnimationEnd=function()
        动画结束()
      end
    })
  end
end
function 透明动画(id,时间,开始透明度,结束透明度,动画结束)
  local 动画=AlphaAnimation(开始透明度, 结束透明度).setDuration(时间)
  id.startAnimation(动画)
  if 动画结束 then
    动画.setAnimationListener(AnimationListener{
      onAnimationEnd=function()
        动画结束()
      end
    })
  end
end
function 缩放动画(id,time,FromX,ToX,FromY,ToY,FXtype,TXtype,FYtype,TYtype,动画结束)
  local 动画=ScaleAnimation(FromX, ToX, FromY, ToY, FXtype, TXtype, FYtype, TYtype).setDuration(time)
  id.startAnimation(动画)
  if 动画结束 then
    动画.setAnimationListener(AnimationListener{
      onAnimationEnd=function()
        动画结束()
      end
    })
  end
end
function DrawingChaceCapture(fileName,view,msg,needSave)
  view.destroyDrawingCache()
  view.setDrawingCacheEnabled(true)
  view.buildDrawingCache()
  viewBm=view.getDrawingCache()
  if needSave==nil or needSave==true then
    存图片(fileName,viewBm,msg)
  end
  view.setDrawingCacheEnabled(false)
end
function getViewBitmap(view)
  view.destroyDrawingCache()
  view.setDrawingCacheEnabled(true)
  view.buildDrawingCache()
  return view.getDrawingCache()
end
function 存图片(文件名,位图,msg)
  if 位图 then
    import "java.io.FileOutputStream"
    import "java.io.File"
    import "android.graphics.Bitmap"    
    if pcall(function ()
    out = FileOutputStream(File(tostring(文件名)))
    位图.compress(Bitmap.CompressFormat.PNG,90, out)
    out.flush()
    out.close()
    end) then
    提示("已保存至:  "..文件名)
    if msg then
    弹出消息(tostring(msg),nil,nil,nil,长toast)
    end
    return true
    else
    提示"保存失败"
     return false
  end
   else
   提示"保存失败"
    return false
  end
end
function getViewBitmap(view)
  view.destroyDrawingCache()
  view.setDrawingCacheEnabled(true)
  view.buildDrawingCache()
  return view.getDrawingCache()
end
function 复制文本(文本)
  activity.getSystemService(Context.CLIPBOARD_SERVICE).setText(文本)
end
function 分享文本(文本)
  intent=Intent(Intent.ACTION_SEND); 
  intent.setType("text/plain"); 
  intent.putExtra(Intent.EXTRA_SUBJECT, "分享"); 
  intent.putExtra(Intent.EXTRA_TEXT,文本); 
  intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
  activity.startActivity(Intent.createChooser(intent,"分享到:"));
end
function 字体(t)
  return Typeface.createFromFile(File(activity.getLuaDir().."/res/"..t..".ttf"))
end
function 获取文件md5(path,fun)
  require"import"
  import"com.androlua.LuaUtil"
  md5=LuaUtil.getFileMD5(tostring(path))
  if not md5 then
    md5="获取失败"
  end
  if fun then
    call(fun,md5)
  end
  return md5
end
function 下载(url,path)
  function xdc(url,path)
    require"import"
    import"java.net.URL"
    local ur=URL(url)
    import "java.io.File"
    file =File(path);
    local con=ur.openConnection();
    local co=con.getContentLength();
    local is=con.getInputStream();
    local bs=byte[1024]
    local len,read=0,0
    import "java.io.FileOutputStream"
    local wj=FileOutputStream(path);
    len=is.read(bs)
    while len~=-1 do
      wj.write(bs, 0, len);
      read=read+len
      len = is.read(bs)
    end
    wj.close();
    is.close();
    call("下载完成")
  end
  thread(xdc,url,path)
  function 下载完成()
    提示("下载完成，已保存在："..path)
  end
end
function 打开应用(包名)
  import "android.content.Intent"
  import "android.content.pm.PackageManager"
  manager=activity.getPackageManager()
  open=manager.getLaunchIntentForPackage(包名)
  this.startActivity(open)
end
function ms2time(ms)
  date=tostring(Date(ms))
  year=date:sub(#date-4,#date)
  month=(date:sub(5,7)):gsub("Jan","01"):gsub("Feb","02"):gsub("Mar","03"):gsub("Apr","04"):gsub("May","05"):gsub("Jun","06"):gsub("Jul","07"):gsub("Aug","08"):gsub("Sep","09"):gsub("Oct","10"):gsub("Nov","11"):gsub("Dec","12")
  day=date:sub(9,10)
  time=date:sub(12,19)
  return (year.."-"..month.."-"..day.." "..time)
end
function getScreenPhysicalSize(ctx)
  import "android.util.DisplayMetrics"
  dm = DisplayMetrics();
  ctx.getWindowManager().getDefaultDisplay().getMetrics(dm);
  diagonalPixels = Math.sqrt(Math.pow(dm.widthPixels, 2) + Math.pow(dm.heightPixels, 2));
  return diagonalPixels / (160 * dm.density);
end
function 获取完成事件(val,t,fun)
  function 获取完成事件2(val,t)end
  获取完成事件2=fun
  获取完成事件2(val,t)
end
function getFolderSize(path,fun)
  local size=0
  local t=os.time()
  require "import"
  import "java.io.File"
  import "java.lang.String"
  function FindFile(catalog)
    local ls=catalog.listFiles()
    for 次数=0,#ls-1 do
      if 次数==tointeger(#ls/4) or 次数==tointeger(#ls/2) or 次数==tointeger(#ls*0.75) then
        collectgarbage("collect")
      end
      local f=ls[次数]
      if f.isDirectory() then
        FindFile(f)
       else
        size=size+File(tostring(f)).length()
      end
    end
  end
  collectgarbage("collect")
  if tostring(path):find"Table" then
    for i=1,#path do
      if File(tostring(path[i])).isDirectory() then
        FindFile(File(path[i]))
      end
    end
  else
    if File(tostring(path)).isDirectory() then
      FindFile(File(path))
    end
  end
  if size~=0 then
    if size>=1073741824 then
      size=string.format("%.2f",size/1073741824).."GB"
    else
      size=string.format("%.2f",size/1048576).."MB"
    end
  else
    size="0.00MB"
  end
  call("获取完成事件",size,t,fun)
  luajava.clear(f)
  luajava.clear(fun)
  luajava.clear(获取完成事件)
  collectgarbage("collect")
end