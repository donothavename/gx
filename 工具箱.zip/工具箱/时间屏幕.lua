require"import"
import"imports"
activity.setRequestedOrientation(0)
window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION)
window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
activity.setContentView(loadlayout({
  LinearLayout,
  id="sjpmbjbj",
  layout_width="fill",
  layout_height="fill",
  KeepScreenOn="true",
  onClick=function()
    if sjpmdj==0then sjpmbjbj.setBackgroundColor(0xffffffff)sjwb.setTextColor(0xFFD5D4CB)rqwb.setTextColor(0xFFC7C7C7)sjpmdj=nil
    else sjpmbjbj.setBackgroundColor(0xff000000)sjwb.setTextColor(0xffffffff)rqwb.setTextColor(0xffffffff)sjpmdj=0 end
  end,
  {
    LinearLayout,
    id="sjpmwb",
    gravity="center",
    layout_width="fill",
    layout_height="fill",
    orientation="vertical",
    {
      TextView,
      id="sjwb",
      textSize="80sp",
      layout_marginTop="50dp",
      textColor=0xFFD5D4CB,
    },
    {
      TextView,
      id="rqwb",
      layout_gravity="right",
      layout_marginTop="50dp",
      layout_marginRight="50dp",
      textColor=0xFFC7C7C7,
    },
  },
}))
function gxsj()
  sjwb.setText(os.date("%H : %M : %S"))rqwb.setText(os.date("Life is Fantastic , today is %A"))
  task(1000,function()
    gxsj()
  end)
end
gxsj()