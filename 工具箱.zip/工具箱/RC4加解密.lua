require"import"
import"imports"
import "android.graphics.drawable.GradientDrawable"
task(2,function()
this.setContentView(loadlayout({
  LinearLayout,
  orientation="vertical",
  backgroundColor=0xFF9AAEC7,
  {
    LinearLayout,
    layout_width=w,
    layout_height="56dp",
    backgroundColor=0xFF9AAEC7,
    layout_marginTop=getStatusBarHeight(),
    {
      TextView,
      textSize="18dp",
      text="RC4加解密",
      textColor=0xffffffff,
      layout_gravity="center",
      layout_marginLeft="16dp",
    },
  },
  {
    LinearLayout,
    layout_width=w,
    orientation="vertical",
    backgroundColor=0xffffffff,
    layout_height=h-getStatusBarHeight()-56*scale,
    {
      EditText,
      id="srwb",
      gravity="top",
      padding="16dp",
      layout_width="fill",
      textColor=0xff000000,
      hintTextColor=0xffa1a1a1,
      backgroundColor=0xffffffff,
      layout_height=(h-112*scale-getStatusBarHeight())/2,
      hint="请输入内容，点击右侧的图标加密内容，点击左侧的图标解密内容..",
    },
    {
      LinearLayout,
      layout_width=w,
      layout_height="56dp",
      orientation="horizontal",
      background="#FFFAFAFA",
      {
        FrameLayout,
        id="jiemrc4bj",
        layout_width="56dp",
        {
          ImageView,
          id="jiemrc4",
          padding="16dp",
          layout_width="56dp",
          layout_height="56dp",
          ColorFilter=0xFFFFFFFF,
          src="http://shp.qpic.cn/collector/2530648358/8bc118fd-159d-4544-8131-5ca10c71678e/0",
          onClick=function()
            if srwb.text~="" and rc4key.text~="" and #srwb.text%2==0 then
              miwen=string.lower(srwb.text):gsub("a",""):gsub("b",""):gsub("c",""):gsub("d",""):gsub("e",""):gsub("f",""):gsub("0",""):gsub("1",""):gsub("2",""):gsub("3",""):gsub("4",""):gsub("5",""):gsub("6",""):gsub("7",""):gsub("8",""):gsub("9","")
              if miwen=="" then
                jmwb.text=RC4解密(srwb.text,rc4key.text)
              end
            end
          end,
        },
      },
      {
        EditText,
        id="rc4key",
        singleLine=true,
        layout_weight="1",
        hint="请输入密钥..",
        layout_gravity="center",
        textColor=0xFF000000,
        background="#FFFAFAFA",
        hintTextColor=0xffa1a1a1,
      },
      {
        FrameLayout,
        id="jiamrc4bj",
        layout_width="56dp",
        {
          ImageView,
          id="jiamrc4",
          padding="16dp",
          layout_width="56dp",
          layout_height="56dp",
          ColorFilter=0xFFFFFFFF,
          src="http://shp.qpic.cn/collector/2530648358/074ecb47-7dc6-4efa-a075-a31ce1d8ff56/0",
          onClick=function()
            if srwb.text~="" and rc4key.text~="" then
              jmwb.text=RC4加密(srwb.text,rc4key.text)
            end
          end,
        },
      },
    },
    {
      EditText,
      id="jmwb",
      gravity="top",
      padding="16dp",
      layout_width=w,
      hint="内容输出..",
      layout_weight="1",
      backgroundColor=0x0,
      textColor=0xff000000,
      hintTextColor=0xffa1a1a1,
    },
    {
      ImageView,
      id="fzjg",
      padding="16dp",
      layout_width="56dp",
      layout_height="56dp",
      layout_gravity="right",
      src="http://shp.qpic.cn/collector/2530648358/936bf7ca-d0f1-4f81-b0d1-ddd28b7255a3/0",
      onClick=function()
        复制文本(jmwb.text)
        提示"复制完成"
      end,
    },
  },
}))
jiemrc4bj.setBackgroundDrawable(GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,{0xFF9AAEC7,0xFFFAFAFA}))
jiamrc4bj.setBackgroundDrawable(GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,{0xFFFAFAFA,0xFF9AAEC7}))
波纹(fzjg,0xFFE2E2E2)波纹方(jiemrc4,0xFFA3B5C3)波纹方(jiamrc4,0xFFA3B5C3)
颜色(jmwb,0xFF68AFE5)颜色(srwb,0xFF68AFE5)颜色(rc4key,0xFF68AFE5)
function KSA(key)
  S={}
  for i=1,256 do
    S[i]=i-1
  end
  j=0
  for i=1,256 do
    if i%#key==0 then
      j=(j+S[i]+key[#key])%256
    else
      j=(j+S[i]+key[i%#key])%256
    end
    S[i],S[j+1]=S[j+1],S[i] 
  end
  return S
end
function PRGA(S,n)
  i,j=0,0
  key={}
  while n>0 do
    i=(i+1)%256
    j=(j+S[i+1])%256
    S[i+1],S[j+1]=S[j+1],S[i+1]
    K=S[(S[i+1]+S[j+1])%256+1]
    key[#key+1]=K
    n=n-1
  end
  return key
end
function preparing_key_array(s)
  c={}
  for i=1,#s do
    c[i]=string.byte(s,i)
  end
  return c
end
function RC4加密(str,key)
  key=key
  plaintext=str
  key=preparing_key_array(key)
  S=KSA(key)
  keystream=PRGA(S,#plaintext)
  plaintext=preparing_key_array(plaintext)
  cipher={}
  for i=1,#plaintext do
    cipher[i]=keystream[i]~plaintext[i]
  end
  jmjg=""
  for i=1,#cipher do
    hexv=Integer.toHexString(cipher[i])
    if #hexv==1 then
      jmjg=jmjg.."0"..hexv
    else
      jmjg=jmjg..hexv
    end
  end
  return jmjg
end
function rc4Hex2Dec(Hex)
  Hexs=(Hex:sub(1,1):gsub("a","10"):gsub("b","11"):gsub("c","12"):gsub("d","13"):gsub("e","14"):gsub("f",15))*15
  Hexg=(Hex:sub(2,2)):gsub("a","10"):gsub("b","11"):gsub("c","12"):gsub("d","13"):gsub("e","14"):gsub("f",15)+Hexs/15
  Dec=tonumber(Hexs+Hexg)
  return Dec
end
function RC4解密(str,key)
  key=key
  plaintext=str
  key=preparing_key_array(key)
  S=KSA(key)
  keystream=PRGA(S,#plaintext/2)
  jmjg=""
  for i=1,#keystream do
    jmjg=jmjg..string.char(rc4Hex2Dec(string.lower(plaintext:sub(i*2-1,i*2)))~keystream[i])
  end
  return jmjg
end
end)