require"import"
import"imports"
task(2,function()
File("/data/data/"..activity.getPackageName().."/翻译收藏").createNewFile()
File("/data/data/"..activity.getPackageName().."/翻译语言").createNewFile()
if io.open("/data/data/"..activity.getPackageName().."/翻译收藏"):read("*a")==""then
io.open("/data/data/"..activity.getPackageName().."/翻译收藏","w+"):write("{\n--翻译收藏\n}"):close()
end
if io.open("/data/data/"..activity.getPackageName().."/翻译语言"):read("*a")==""then
io.open("/data/data/"..activity.getPackageName().."/翻译语言","w+"):write('"from":"智能检测"\n"to":"中文"'):close()
end
翻译语言={
["智能检测"]="auto",
["阿尔巴尼亚语"]="sq",
["阿拉伯语"]="ar",
["阿姆哈拉语"]="am",
["阿塞拜疆语"]="az",
["爱尔兰语"]="ga",
["爱沙尼亚语"]="et",
["巴斯克语"]="eu",
["白俄罗斯语"]="be",
["保加利亚语"]="bg",
["冰岛语"]="is",
["波兰语"]="pl",
["波斯尼亚语"]="bs",
["波斯语"]="fa",
["布尔语(南非荷兰语)"]="af",
["丹麦语"]="da",
["德语"]="de",
["俄语"]="ru",
["法语"]="fr",
["菲律宾语"]="tl",
["芬兰语"]="fi",
["弗里西语"]="fy",
["高棉语"]="km",
["格鲁吉亚语"]="ka",
["古吉拉特语"]="gu",
["哈萨克语"]="kk",
["海地克里奥尔语"]="ht",
["韩语"]="ko",
["豪萨语"]="ha",
["荷兰语"]="nl",
["吉尔吉斯语"]="ky",
["加利西亚语"]="gl",
["加泰罗尼亚语"]="ca",
["捷克语"]="cs",
["卡纳达语"]="kn",
["科西嘉语"]="co",
["克罗地亚语"]="hr",
["库尔德语"]="ku",
["拉丁语"]="la",
["拉脱维亚语"]="lv",
["老挝语"]="lo",
["立陶宛语"]="lt",
["卢森堡语"]="lb",
["罗马尼亚语"]="ro",
["马尔加什语"]="mg",
["马耳他语"]="mt",
["马拉地语"]="mr",
["马拉雅拉姆语"]="ml",
["马来语"]="ms",
["马其顿语"]="mk",
["毛利语"]="mi",
["蒙古语"]="mn",
["孟加拉语"]="bn",
["缅甸语"]="my",
["苗语"]="hmn",
["南非科萨语"]="xh",
["南非祖鲁语"]="zu",
["尼泊尔语"]="ne",
["挪威语"]="no",
["旁遮普语"]="pa",
["葡萄牙语"]="pt",
["普什图语"]="ps",
["齐切瓦语"]="ny",
["日语"]="ja",
["瑞典语"]="sv",
["萨摩亚语"]="sm",
["塞尔维亚语"]="sr",
["塞索托语"]="st",
["僧伽罗语"]="si",
["世界语"]="eo",
["斯洛伐克语"]="sk",
["斯洛文尼亚语"]="sl",
["斯瓦希里语"]="sw",
["苏格兰盖尔语"]="gd",
["宿务语"]="ceb",
["索马里语"]="so",
["塔吉克语"]="tg",
["泰卢固语"]="te",
["泰米尔语"]="ta",
["泰语"]="th",
["土耳其语"]="tr",
["威尔士语"]="cy",
["乌尔都语"]="ur",
["乌克兰语"]="uk",
["乌兹别克语"]="uz",
["西班牙语"]="es",
["希伯来语"]="iw",
["希腊语"]="el",
["夏威夷语"]="haw",
["信德语"]="sd",
["匈牙利语"]="hu",
["修纳语"]="sn",
["亚美尼亚语"]="hy",
["伊博语"]="ig",
["意大利语"]="it",
["意第绪语"]="yi",
["印地语"]="hi",
["印尼巽他语"]="su",
["印尼语"]="id",
["印尼爪哇语"]="jw",
["英语"]="en",
["约鲁巴语"]="yo",
["越南语"]="vi",
["中文"]="zh-CN",
["中文(繁体)"]="zh-TW",
}
activity.setContentView(loadlayout({
  LinearLayout,
  orientation="vertical",
  layout_height=h,
  backgroundColor=0xFF9AAEC7,
  {
    LinearLayout,
    layout_width=w,
    gravity="bottom",
    orientation="horizontal",
    layout_height=56*scale+getStatusBarHeight(),
    {
      ImageView,
      padding="17dp",
      layout_width="56dp",
      layout_height="56dp",
      src="http://shp.qpic.cn/collector/2530648358/6ce8ce2c-f0ac-4c11-b6c1-2c7daf86ac60/0",
      ColorFilter=0xffffffff,
      onClick=function()activity.finish()()end,
    },
    {
      LinearLayout,
      layout_weight="1",
      layout_marginLeft="12dp",
      layout_height="56dp",
      {
        TextView,
        textSize="18dp",
        layout_gravity="center",
        textColor=0xffffffff,
        text="翻译",
        backgroundColor=0xFF9AAEC7,
      },
    },
    {
      ImageView,
      padding="17dp",
      layout_width="56dp",
      layout_height="56dp",
      src="http://shp.qpic.cn/collector/2530648358/fa484b1f-6510-45d3-b8fd-be3cf0e8f7ce/0",
      ColorFilter=0xffffffff,
      onClick=function()activity.newActivity("翻译收藏")end,
    },
  },
  {
    CardView,
    layout_width=w,
    layout_height=h,
    elevation=0,
    radius="10dp",
    cardBackgroundColor=0xffffffff,
    {
      ScrollView;
      layout_width=w,
      layout_height=h-56*scale-getStatusBarHeight(),
      VerticalScrollBarEnabled=false,
      {
        LinearLayout,
        layout_width="fill",
        orientation="vertical",
        {
          LinearLayout,
          layout_width="fill",
          layout_height="48dp",
          {
            TextView,
            id="fyfrom",
            textSize="18sp",
            layout_height="fill",
            paddingLeft="24dp",
            gravity="left|center",
            textColor=0xFF68AFE5,
            layout_width=(w-2*scale)/2,
            text=io.open("/data/data/"..activity.getPackageName().."/翻译语言"):read("*a"):match('"from":"(.-)"'),
            onClick=function()
              activity.newActivity("选择翻译语言")
            end,
          },
          {
            TextView,
            layout_width="2dp",
            layout_height="15dp",
            layout_gravity="center",
            backgroundColor=0xffededed,
          },
          {
            TextView,
            id="fyto",
            textSize="18sp",
            layout_height="fill",
            paddingRight="24dp",
            gravity="right|center",
            textColor=0xFF68AFE5,
            layout_width=(w-2*scale)/2,
            text=io.open("/data/data/"..activity.getPackageName().."/翻译语言"):read("*a"):match('"to":"(.-)"'),
            onClick=function()
              activity.newActivity("选择翻译语言",{"true"})
            end
          },
        },
        {
          EditText,
          id="dfywb",
          gravity="top",
          layout_width="fill",
          hint="请输入文字..",
          MinHeight="170dp",
          paddingLeft="24dp",
          paddingRight="24dp",
          textColor=0xff000000,
          Typeface=字体("product"),
          backgroundColor=0xffffffff,
        },
        {
            LinearLayout,
            gravity="center",
            layout_width="56dp",
            layout_gravity="right",
            layout_height="56dp",
            layout_marginTop="-52dp",
            layout_marginRight="24dp",
            {
              ImageView,
              id="qcfynr",
              padding="12dp",
              layout_width="48dp",
              layout_height="48dp",
              Visibility=4,
              src="http://shp.qpic.cn/collector/2530648358/c5794b00-8e26-4e15-88cf-008d722098cd/0",
              ColorFilter=0xFF767774,
              onClick=function()dfywb.text=""fyjg.text=""end,
            },
          },
        {
          FrameLayout,
          layout_width="fill",
          paddingLeft="24dp",
          paddingRight="24dp",
          layout_marginTop="-15dp",
          {
            CardView,
            elevation=0,
            radius="6dp",
            layout_width="fill",
            layout_marginTop="28dp",
            layout_marginBottom="30dp",
            cardBackgroundColor=0xfff5f5f5,
            {
              LinearLayout,
              layout_width="fill",
              orientation="vertical",
              layout_marginTop="30dp",
              {
                TextView,
                id="fyjg",
                padding="16dp",
                textSize="18sp",
                textIsSelectable=true,
                textColor=0xff000000,
                Typeface=字体("product"),
              },
              {
                LinearLayout,
                gravity="right",
                layout_width="fill",
                layout_height="48dp",
                orientation="horizontal",
                layout_margin="8dp",
                {
                  ImageView,
                  id="tts",
                  padding="12dp",
                  layout_width="48dp",
                  layout_height="48dp",
                  src="http://shp.qpic.cn/collector/2530648358/e7ca2ca5-e259-4466-89bb-6b4f4952dd6a/0",
                  ColorFilter=0xFF767774,
                  onClick=function()
                    if fyjg.text~=""then
                      import "android.speech.tts.*"
                      mTextSpeech=TextToSpeech(activity,TextToSpeech.OnInitListener{
                        onInit=function(status)
                          if status==TextToSpeech.SUCCESS then
                            result=mTextSpeech.setLanguage(Locale.CHINESE)
                            if result==TextToSpeech.LANG_MISSING_DATA or result==TextToSpeech.LANG_NOT_SUPPORTED then
                              提示("您的手机不支持"..io.open("/data/data/"..activity.getPackageName().."/翻译语言"):read("*a"):match('"to":"(.-)"').."语音播报功能。")
                            else
                              mTextSpeech.setPitch(1);
                              mTextSpeech.setSpeechRate(1)
                              mTextSpeech.speak(fyjg.text,TextToSpeech.QUEUE_FLUSH,nil)
                            end
                          else
                            提示"未装载系统TTS"
                          end
                        end
                      })
                    end
                  end,
                },
                {
                  ImageView,
                  id="fzfyjg",
                  padding="12dp",
                  layout_width="48dp",
                  layout_height="48dp",
                  src="http://shp.qpic.cn/collector/2530648358/2ed5c4e9-7155-4732-a87e-ca8de59965e4/0",
                  ColorFilter=0xFF767774,
                  onClick=function()复制文本(fyjg.text)提示"复制完成"end,
                },
                {
                  ImageView,
                  id="tjfysc",
                  padding="12dp",
                  layout_width="48dp",
                  layout_height="48dp",
                  src="http://shp.qpic.cn/collector/2530648358/fa484b1f-6510-45d3-b8fd-be3cf0e8f7ce/0",
                  ColorFilter=0xFF767774,
                  onClick=function()
                    if fyjg.text~="" then
                      dqfysc=io.open("/data/data/"..activity.getPackageName().."/翻译收藏"):read("*a")
                      翻译收藏文本=io.open("/data/data/"..activity.getPackageName().."/翻译收藏"):read("*a")
                      翻译收藏文本=loadstring("return "..翻译收藏文本)()
                      for i=1,#翻译收藏文本+1 do 
                        if 翻译收藏文本[i]==(dfywb.text.."  |  "..fyjg.text) then
                          break
                        elseif i==#翻译收藏文本+1 then
                          xrfysc=dqfysc:gsub("--翻译收藏","[["..dfywb.text.."  |  "..fyjg.text.."]],\n--翻译收藏")
                          io.open("/data/data/"..activity.getPackageName().."/翻译收藏","w+"):write(xrfysc):close()
                        end
                      end
                      提示"好了"
                    end
                  end,
                },
              },
            },
          },
          {
            CardView,
            radius="32dp",
            elevation=0,
            layout_width="64dp",
            layout_height="64dp",
            layout_gravity="center|top",
            cardBackgroundColor=0xffffffff,
            {
              FrameLayout,
              layout_width="56dp",
              layout_height="56dp",
              layout_gravity="center",
              {
                ProgressBar,
                id="pgb",
                layout_width="56dp",
                layout_height="56dp",
              },
              {
                CardView,
                id="fytx",
                elevation=0,
                radius="28dp",
                layout_width="56dp",
                layout_height="56dp",
                layout_gravity="center",
                cardBackgroundColor=0xFF68AFE5,
                {
                  ImageView,
                  id="fyan",
                  padding="16dp",
                  layout_width="56dp",
                  layout_height="56dp",
                  layout_gravity="center",
                  src="http://shp.qpic.cn/collector/2530648358/d0cf7f32-adbb-46e6-aa2d-5271998148ab/0",
                  ColorFilter=0xffffffff,
                  onClick=function()if dfywb.text~=""then 翻译动画()else 提示"未输入"end end,
                },
              },
            },
          },
        },
      },
    },
  },
}))
dfywb.addTextChangedListener({
  onTextChanged=function()
  if dfywb.text=="" then
    qcfynr.setVisibility(4)
  else
    qcfynr.setVisibility(0)
  end
end})
function onResume()
  fyfrom.text=io.open("/data/data/"..activity.getPackageName().."/翻译语言"):read("*a"):match('"from":"(.-)"')
  fyto.text=io.open("/data/data/"..activity.getPackageName().."/翻译语言"):read("*a"):match('"to":"(.-)"')
end
function Hex2Dec(Hex)
  Hexs=(Hex:sub(1,1):gsub("a","10"):gsub("b","11"):gsub("c","12"):gsub("d","13"):gsub("e","14"):gsub("f",15))*15
  Hexg=(Hex:sub(2,2)):gsub("a","10"):gsub("b","11"):gsub("c","12"):gsub("d","13"):gsub("e","14"):gsub("f",15)+Hexs/15
  Dec=tonumber(Hexs+Hexg)
  return Dec
end
function 翻译动画()
  缩放按钮=ScaleAnimation(1,0.6,1,0.6,相对自身,0.5,相对自身,0.5).setDuration(200).setFillAfter(true)
  fytx.startAnimation(缩放按钮)
  缩放按钮=ScaleAnimation(0.6,1,0.6,1,相对自身,0.5,相对自身,0.5).setDuration(200).setFillAfter(true)
  import "com.kn.rhino.*"
  import "java.net.URLEncoder"
  res=Js.runFunction(activity,[[function token(a) {
      var k = "";
      var b = 406644;
      var b1 = 3293161072;
      var jd = ".";
      var sb = "+-a^+6";
      var Zb = "+-3^+b+-f";
      for (var e = [], f = 0, g = 0; g < a.length; g++) {
          var m = a.charCodeAt(g);
          128 > m ? e[f++] = m: (2048 > m ? e[f++] = m >> 6 | 192 : (55296 == (m & 64512) && g + 1 < a.length && 56320 == (a.charCodeAt(g + 1) & 64512) ? (m = 65536 + ((m & 1023) << 10) + (a.charCodeAt(++g) & 1023), e[f++] = m >> 18 | 240, e[f++] = m >> 12 & 63 | 128) : e[f++] = m >> 12 | 224, e[f++] = m >> 6 & 63 | 128), e[f++] = m & 63 | 128)
      }
      a = b;
      for (f = 0; f < e.length; f++) a += e[f],
      a = RL(a, sb);
      a = RL(a, Zb);
      a ^= b1 || 0;
      0 > a && (a = (a & 2147483647) + 2147483648);
      a %= 1E6;
      return a.toString() + jd + (a ^ b)
  };
  function RL(a, b) {
      var t = "a";
      var Yb = "+";
      for (var c = 0; c < b.length - 2; c += 3) {
          var d = b.charAt(c + 2),
          d = d >= t ? d.charCodeAt(0) - 87 : Number(d),
          d = b.charAt(c + 1) == Yb ? a >>> d: a << d;
          a = b.charAt(c) == Yb ? a + d & 4294967295 : a ^ d ;
      }
      return a
  };]],"token",{dfywb.text})
  url="https://translate.google.cn/translate_a/single?"
  datastr=""
  data={"client=webapp",
    "sl="..翻译语言[io.open("/data/data/"..activity.getPackageName().."/翻译语言"):read("*a"):match('"from":"(.-)"')],
    "tl="..翻译语言[io.open("/data/data/"..activity.getPackageName().."/翻译语言"):read("*a"):match('"to":"(.-)"')],
    "hl=zh-CN",
    "dt=at",
    "dt=bd",
    "dt=ex",
    "dt=ld",
    "dt=md",
    "dt=qca",
    "dt=rw",
    "dt=rm",
    "dt=ss",
    "dt=t",
    "ie=UTF-8",
    "oe=UTF-8",
    "source=btn",
    "ssel=0",
    "tsel=0",
    "kc=0",
    "tk="..res,
    "q="..URLEncoder.encode(dfywb.text)}
    datastr=table.concat(data,"&")
    Http.get(url..datastr,{["User-Agent"]="Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_0 like Mac OS X; en-us) AppleWebKit/532.9 (KHTML, like Gecko) Version/4.0.5 Mobile/8A293 Safari/6531.22.7"},function(code,content)
    if code==-1then
      提示"连接失败"
      fytx.startAnimation(缩放按钮)
    else
      翻译结果=""
      for i=1,#content do
        if string.byte(content:sub(i,i))==91 then
          翻译结果=翻译结果.."{"
        elseif string.byte(content:sub(i,i))==93 then
          翻译结果=翻译结果.."}"
        else
          翻译结果=翻译结果..content:sub(i,i)
        end
      end
      翻译结果=翻译结果:gsub("\n","")
      while 翻译结果:find[[\u]] do
       开头,结尾=string.find(翻译结果,[[\u]])
       翻译结果=翻译结果:sub(1,开头-1)..string.char(Hex2Dec(翻译结果:sub(结尾+3,结尾+4)))..翻译结果:sub(结尾+5,#翻译结果)
      end
      翻译结果表=loadstring("return "..翻译结果)()
      翻译结果=""
      for i=1,(#(翻译结果表[1]))-1 do
        翻译结果=翻译结果..翻译结果表[1][i][1]
      end
      fyjg.text=翻译结果
      fytx.startAnimation(缩放按钮)
    end
  end)
end
波纹(fyan,0xFF477597)波纹(fzfyjg,0xFFD9D9D9)波纹(qcfynr,0xFFD9D9D9)波纹(tts,0xFFD9D9D9)波纹(tjfysc,0xFFD9D9D9)波纹方(fyfrom,0xFFD9D9D9)波纹方(fyto,0xFFD9D9D9)
颜色(dfywb,0xFF68AFE5)
pgb.IndeterminateDrawable.setColorFilter(PorterDuffColorFilter(0xFF68AFE5,PorterDuff.Mode.SRC_ATOP))
end)