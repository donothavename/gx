require"import"
import"imports"
task(2,function()
this.setContentView(loadlayout({
  LinearLayout,
  layout_width=w,
  layout_height=h,
  orientation="vertical",
  backgroundColor=0xFFFFFFFF,
  {
    TextView,
    id="srzf",
    visibility=8,
    maxLines="2",
    padding="16dp",
    layout_width=w,
    textSize="20sp",
    layout_height="60dp",
    textColor=0xFF000000,
    layout_marginTop="16dp",
    Typeface=Typeface.DEFAULT_BOLD,
  },
  {
    TextView,
    id="lzf",
    text="0",
    padding="16dp",
    layout_width=w,
    textSize="20sp",
    layout_height="60dp",
    textColor=0xFF000000,
    layout_marginTop="16dp",
    Typeface=Typeface.DEFAULT_BOLD,
  },
  {
    LinearLayout,
    layout_width="fill",
    layout_height="3dp",
    layout_marginLeft="16dp",
    layout_marginRight="16dp",
    backgroundColor=0xFF68AFE5,
  },
  {
    LinearLayout,
    padding="16dp",
    layout_width=w,
    orientation="vertical",
    layout_marginTop="16dp",
    {
      LinearLayout,
      layout_width="fill",
      orientation="horizontal",
      {
        Button,
        id="Binan",
        text="BIN",
        textSize="16sp",
        textColor=0xFFFFFFFF,
        layout_marginRight="16dp",
        onClick=function()
          fromjz="Bin"
          srzf.setVisibility(8)lzf.setVisibility(0)
          srzf.text="" Binwb.text="" Octwb.text="" Decwb.text="" Hexwb.text=""
          sr2.setTextColor(0xFFB2B2B2)sr3.setTextColor(0xFFB2B2B2)sr4.setTextColor(0xFFB2B2B2)sr5.setTextColor(0xFFB2B2B2)sr6.setTextColor(0xFFB2B2B2)sr7.setTextColor(0xFFB2B2B2)sr8.setTextColor(0xFFB2B2B2)sr9.setTextColor(0xFFB2B2B2)srA.setTextColor(0xFFB2B2B2)srB.setTextColor(0xFFB2B2B2)srC.setTextColor(0xFFB2B2B2)srD.setTextColor(0xFFB2B2B2)srE.setTextColor(0xFFB2B2B2)srF.setTextColor(0xFFB2B2B2)
          波纹(sr2,0x0)波纹(sr3,0x0)波纹(sr4,0x0)波纹(sr5,0x0)波纹(sr6,0x0)波纹(sr7,0x0)波纹(sr8,0x0)波纹(sr9,0x0)波纹(srA,0x0)波纹(srB,0x0)波纹(srC,0x0)波纹(srD,0x0)波纹(srE,0x0)波纹(srF,0x0)
          Binan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF68AFE5,PorterDuff.Mode.SRC_ATOP))
          Octan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF9E9E9E,PorterDuff.Mode.SRC_ATOP))
          Decan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF9E9E9E,PorterDuff.Mode.SRC_ATOP))
          Hexan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF9E9E9E,PorterDuff.Mode.SRC_ATOP))
        end,
      },
      {
        TextView,
        id="Binwb",
        maxLines=3,
        text="\n\n\n",
        ellipsize="end",
        textSize="18sp",
        layout_weight="1",
        layout_width="fill",
        paddingBottom="12dp",
        textColor=0xFF727272,
        layout_marginTop="-10dp",
        onClick=function()
          if Binwb.text~="" then
            复制文本(Binwb.text)
            提示"复制完成"
          end
        end
      },
    },
    {
      LinearLayout,
      layout_width="fill",
      orientation="horizontal",
      {
        Button,
        id="Octan",
        text="OCT",
        textSize="16sp",
        textColor=0xFFFFFFFF,
        layout_marginRight="16dp",
        onClick=function()
          fromjz="Oct"
          srzf.setVisibility(8)lzf.setVisibility(0)
          srzf.text="" Binwb.text="" Octwb.text="" Decwb.text="" Hexwb.text=""
          sr8.setTextColor(0xFFB2B2B2)sr9.setTextColor(0xFFB2B2B2)srA.setTextColor(0xFFB2B2B2)srB.setTextColor(0xFFB2B2B2)srC.setTextColor(0xFFB2B2B2)srD.setTextColor(0xFFB2B2B2)srE.setTextColor(0xFFB2B2B2)srF.setTextColor(0xFFB2B2B2)
          波纹(sr8,0x0)波纹(sr9,0x0)波纹(srA,0x0)波纹(srB,0x0)波纹(srC,0x0)波纹(srD,0x0)波纹(srE,0x0)波纹(srF,0x0)
          sr2.setTextColor(0xFF000000)sr3.setTextColor(0xFF000000)sr4.setTextColor(0xFF000000)sr5.setTextColor(0xFF000000)sr6.setTextColor(0xFF000000)sr7.setTextColor(0xFF000000)
          波纹(sr2,0xFF68AFE5)波纹(sr3,0xFF68AFE5)波纹(sr4,0xFF68AFE5)波纹(sr5,0xFF68AFE5)波纹(sr6,0xFF68AFE5)波纹(sr7,0xFF68AFE5)
          Binan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF9E9E9E,PorterDuff.Mode.SRC_ATOP))
          Octan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF68AFE5,PorterDuff.Mode.SRC_ATOP))
          Decan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF9E9E9E,PorterDuff.Mode.SRC_ATOP))
          Hexan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF9E9E9E,PorterDuff.Mode.SRC_ATOP))
        end
      },
      {
        TextView,
        id="Octwb",
        maxLines=3,
        text="\n\n\n",
        ellipsize="end",
        textSize="18sp",
        layout_weight="1",
        layout_width="fill",
        paddingBottom="12dp",
        textColor=0xFF727272,
        layout_marginTop="-10dp",
        onClick=function()
          if Octwb.text~="" then
            复制文本(Octwb.text)
            提示"复制完成"
          end
        end
      },
    },
    {
      LinearLayout,
      layout_width="fill",
      orientation="horizontal",
      {
        Button,
        id="Decan",
        text="DEC",
        textSize="16sp",
        textColor=0xFFFFFFFF,
        layout_marginRight="16dp",
        onClick=function()
          fromjz="Dec"
          srzf.setVisibility(8)lzf.setVisibility(0)
          srzf.text="" Binwb.text="" Octwb.text="" Decwb.text="" Hexwb.text=""
          srA.setTextColor(0xFFB2B2B2)srB.setTextColor(0xFFB2B2B2)srC.setTextColor(0xFFB2B2B2)srD.setTextColor(0xFFB2B2B2)srE.setTextColor(0xFFB2B2B2)srF.setTextColor(0xFFB2B2B2)
          波纹(srA,0x0)波纹(srB,0x0)波纹(srC,0x0)波纹(srD,0x0)波纹(srE,0x0)波纹(srF,0x0)
          sr2.setTextColor(0xFF000000)sr3.setTextColor(0xFF000000)sr4.setTextColor(0xFF000000)sr5.setTextColor(0xFF000000)sr6.setTextColor(0xFF000000)sr7.setTextColor(0xFF000000)sr8.setTextColor(0xFF000000)sr9.setTextColor(0xFF000000)
          波纹(sr2,0xFF68AFE5)波纹(sr3,0xFF68AFE5)波纹(sr4,0xFF68AFE5)波纹(sr5,0xFF68AFE5)波纹(sr6,0xFF68AFE5)波纹(sr7,0xFF68AFE5)波纹(sr8,0xFF68AFE5)波纹(sr9,0xFF68AFE5)
          Binan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF9E9E9E,PorterDuff.Mode.SRC_ATOP))
          Octan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF9E9E9E,PorterDuff.Mode.SRC_ATOP))
          Decan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF68AFE5,PorterDuff.Mode.SRC_ATOP))
          Hexan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF9E9E9E,PorterDuff.Mode.SRC_ATOP))
        end
      },
      {
        TextView,
        id="Decwb",
        maxLines=3,
        text="\n\n\n",
        ellipsize="end",
        textSize="18sp",
        layout_weight="1",
        layout_width="fill",
        paddingBottom="12dp",
        textColor=0xFF727272,
        layout_marginTop="-10dp",
        onClick=function()
          if Decwb.text~="" then
            复制文本(Decwb.text)
            提示"复制完成"
          end
        end
      },
    },
    {
      LinearLayout,
      layout_width="fill",
      orientation="horizontal",
      {
        Button,
        id="Hexan",
        text="HEX",
        textSize="16sp",
        textColor=0xFFFFFFFF,
        layout_marginRight="16dp",
        onClick=function()
          fromjz="Hex"
          srzf.setVisibility(8)lzf.setVisibility(0)
          srzf.text="" Binwb.text="" Octwb.text="" Decwb.text="" Hexwb.text=""          
          sr2.setTextColor(0xFF000000)sr3.setTextColor(0xFF000000)sr4.setTextColor(0xFF000000)sr5.setTextColor(0xFF000000)sr6.setTextColor(0xFF000000)sr7.setTextColor(0xFF000000)sr8.setTextColor(0xFF000000)sr9.setTextColor(0xFF000000)srA.setTextColor(0xFF000000)srB.setTextColor(0xFF000000)srC.setTextColor(0xFF000000)srD.setTextColor(0xFF000000)srE.setTextColor(0xFF000000)srF.setTextColor(0xFF000000)
          波纹(sr2,0xFF68AFE5)波纹(sr3,0xFF68AFE5)波纹(sr4,0xFF68AFE5)波纹(sr5,0xFF68AFE5)波纹(sr6,0xFF68AFE5)波纹(sr7,0xFF68AFE5)波纹(sr8,0xFF68AFE5)波纹(sr9,0xFF68AFE5)波纹(srA,0xFF68AFE5)波纹(srB,0xFF68AFE5)波纹(srC,0xFF68AFE5)波纹(srD,0xFF68AFE5)波纹(srE,0xFF68AFE5)波纹(srF,0xFF68AFE5)
          Binan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF9E9E9E,PorterDuff.Mode.SRC_ATOP))
          Octan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF9E9E9E,PorterDuff.Mode.SRC_ATOP))
          Decan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF9E9E9E,PorterDuff.Mode.SRC_ATOP))
          Hexan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF68AFE5,PorterDuff.Mode.SRC_ATOP))
        end
      },
      {
        TextView,
        id="Hexwb",
        maxLines=3,
        text="\n\n\n",
        ellipsize="end",
        textSize="18sp",
        layout_weight="1",
        layout_width="fill",
        paddingBottom="12dp",
        textColor=0xFF727272,
        layout_marginTop="-10dp",
        onClick=function()
          if Hexwb.text~="" then
            复制文本(Hexwb.text)
            提示"复制完成"
          end
        end
      },
    },
  },
  {
    LinearLayout,
    padding="16dp",
    layout_width=w,
    layout_height="fill",
    orientation="horizontal",
    {
      LinearLayout,
      layout_height="fill",
      orientation="vertical",
      layout_width=(w-32*scale)/5,
      {
        TextView,
        id="sr1",
        text="1",
        gravity="center",
        textSize="15.6sp",
        layout_width="fill",
        layout_weight="1",
        textColor=0xFF000000,
        Typeface=Typeface.DEFAULT_BOLD,
        onClick=function()
          srzf.setVisibility(0)lzf.setVisibility(8)
          srzf.text=srzf.text.."1"
          if fromjz=="Bin" then
            Binwb.text=q0(srzf.text)
            Octwb.text=q0(Bin2Oct(srzf.text))
            Decwb.text=Bin2Dec(srzf.text)
            Hexwb.text=q0(string.upper(Bin2Hex(srzf.text)))
          elseif fromjz=="Oct" then
            Octwb.text=q0(srzf.text)
            Binwb.text=Oct2Bin(srzf.text)
            Decwb.text=Bin2Dec(Binwb.text)
            Hexwb.text=Bin2Hex(Binwb.text)
          elseif fromjz=="Dec" then
            Decwb.text=q0(srzf.text)
            Binwb.text=Dec2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Hexwb.text=Bin2Hex(Binwb.text)
          else
            Hexwb.text=q0(srzf.text)
            Binwb.text=Hex2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Decwb.text=Bin2Dec(Binwb.text)
          end
        end
      },
      {
        TextView,
        id="sr4",
        text="4",
        gravity="center",
        textSize="15.6sp",
        layout_width="fill",
        layout_weight="1",
        textColor=0xFF000000,
        Typeface=Typeface.DEFAULT_BOLD,
        onClick=function()
          if fromjz~="Bin" then
            srzf.setVisibility(0)lzf.setVisibility(8)
            srzf.text=srzf.text.."4"
          end
          if fromjz=="Oct" then
            Octwb.text=q0(srzf.text)
            Binwb.text=Oct2Bin(srzf.text)
            Decwb.text=Bin2Dec(Binwb.text)
            Hexwb.text=Bin2Hex(Binwb.text)
          elseif fromjz=="Dec" then
            Decwb.text=q0(srzf.text)
            Binwb.text=Dec2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Hexwb.text=Bin2Hex(Binwb.text)
          elseif fromjz=="Hex" then
            Hexwb.text=q0(srzf.text)
            Binwb.text=Hex2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Decwb.text=Bin2Dec(Binwb.text)
          end
        end
      },
      {
        TextView,
        id="sr7",
        text="7",
        gravity="center",
        textSize="15.6sp",
        layout_width="fill",
        layout_weight="1",
        textColor=0xFF000000,
        Typeface=Typeface.DEFAULT_BOLD,
        onClick=function()
          if fromjz~="Bin" then
            srzf.setVisibility(0)lzf.setVisibility(8)
            srzf.text=srzf.text.."7"
          end
          if fromjz=="Oct" then
            Octwb.text=q0(srzf.text)
            Binwb.text=Oct2Bin(srzf.text)
            Decwb.text=Bin2Dec(Binwb.text)
            Hexwb.text=Bin2Hex(Binwb.text)
          elseif fromjz=="Dec" then
            Decwb.text=q0(srzf.text)
            Binwb.text=Dec2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Hexwb.text=Bin2Hex(Binwb.text)
          elseif fromjz=="Hex" then
            Hexwb.text=q0(srzf.text)
            Binwb.text=Hex2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Decwb.text=Bin2Dec(Binwb.text)
          end
        end
      },
      {
        TextView,
        id="sr0",
        text="0",
        gravity="center",
        textSize="15.6sp",
        layout_width="fill",
        layout_weight="1",
        textColor=0xFF000000,
        Typeface=Typeface.DEFAULT_BOLD,
        onClick=function()
          srzf.setVisibility(0)lzf.setVisibility(8)
          srzf.text=srzf.text.."0"
          if fromjz=="Bin" then
            Binwb.text=q0(srzf.text)
            Octwb.text=q0(Bin2Oct(srzf.text))
            Decwb.text=Bin2Dec(srzf.text)
            Hexwb.text=q0(string.upper(Bin2Hex(srzf.text)))
          elseif fromjz=="Oct" then
            Octwb.text=q0(srzf.text)
            Binwb.text=Oct2Bin(srzf.text)
            Decwb.text=Bin2Dec(Binwb.text)
            Hexwb.text=Bin2Hex(Binwb.text)
          elseif fromjz=="Dec" then
            Decwb.text=q0(srzf.text)
            Binwb.text=Dec2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Hexwb.text=Bin2Hex(Binwb.text)
          else
            Hexwb.text=q0(srzf.text)
            Binwb.text=Hex2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Decwb.text=Bin2Dec(Binwb.text)
          end
        end
      },
    },
    {
      LinearLayout,
      layout_height="fill",
      orientation="vertical",
      layout_width=(w-32*scale)/5,
      {
        TextView,
        id="sr2",
        text="2",
        gravity="center",
        textSize="15.6sp",
        layout_width="fill",
        layout_weight="1",
        textColor=0xFF000000,
        Typeface=Typeface.DEFAULT_BOLD,
        onClick=function()
          if fromjz~="Bin" then
            srzf.setVisibility(0)lzf.setVisibility(8)
            srzf.text=srzf.text.."2"
          end
          if fromjz=="Oct" then
            Octwb.text=q0(srzf.text)
            Binwb.text=Oct2Bin(srzf.text)
            Decwb.text=Bin2Dec(Binwb.text)
            Hexwb.text=Bin2Hex(Binwb.text)
          elseif fromjz=="Dec" then
            Decwb.text=q0(srzf.text)
            Binwb.text=Dec2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Hexwb.text=Bin2Hex(Binwb.text)
          elseif fromjz=="Hex" then
            Hexwb.text=q0(srzf.text)
            Binwb.text=Hex2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Decwb.text=Bin2Dec(Binwb.text)
          end
        end
      },
      {
        TextView,
        id="sr5",
        text="5",
        gravity="center",
        textSize="15.6sp",
        layout_width="fill",
        layout_weight="1",
        textColor=0xFF000000,
        Typeface=Typeface.DEFAULT_BOLD,
        onClick=function()
          if fromjz~="Bin" then
            srzf.setVisibility(0)lzf.setVisibility(8)
            srzf.text=srzf.text.."5"
          end
          if fromjz=="Oct" then
            Octwb.text=q0(srzf.text)
            Binwb.text=Oct2Bin(srzf.text)
            Decwb.text=Bin2Dec(Binwb.text)
            Hexwb.text=Bin2Hex(Binwb.text)
          elseif fromjz=="Dec" then
            Decwb.text=q0(srzf.text)
            Binwb.text=Dec2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Hexwb.text=Bin2Hex(Binwb.text)
          elseif fromjz=="Hex" then
            Hexwb.text=q0(srzf.text)
            Binwb.text=Hex2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Decwb.text=Bin2Dec(Binwb.text)
          end
        end
      },
      {
        TextView,
        id="sr8",
        text="8",
        gravity="center",
        textSize="15.6sp",
        layout_width="fill",
        layout_weight="1",
        textColor=0xFF000000,
        Typeface=Typeface.DEFAULT_BOLD,
        onClick=function()
          if fromjz~="Bin" and fromjz~="Oct" then
            srzf.setVisibility(0)lzf.setVisibility(8)
            srzf.text=srzf.text.."8"
          end
          if fromjz=="Dec" then
            Decwb.text=q0(srzf.text)
            Binwb.text=Dec2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Hexwb.text=Bin2Hex(Binwb.text)
          elseif fromjz=="Hex" then
            Hexwb.text=q0(srzf.text)
            Binwb.text=Hex2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Decwb.text=Bin2Dec(Binwb.text)
          end
        end
      },
      {
        TextView,
        id="qksy",
        text="CLR",
        gravity="center",
        textSize="15.6sp",
        layout_width="fill",
        layout_weight="1",
        textColor=0xFF68AFE5,
        Typeface=Typeface.DEFAULT_BOLD,
        onClick=function()
          Binwb.text="" Octwb.text="" Decwb.text="" Hexwb.text=""
          srzf.text="" srzf.setVisibility(8)lzf.setVisibility(0)
        end
      },
    },
    {
      LinearLayout,
      layout_height="fill",
      orientation="vertical",
      layout_width=(w-32*scale)/5,
      {
        TextView,
        id="sr3",
        text="3",
        gravity="center",
        textSize="15.6sp",
        layout_width="fill",
        layout_weight="1",
        textColor=0xFF000000,
        Typeface=Typeface.DEFAULT_BOLD,
        onClick=function()
          if fromjz~="Bin" then
            srzf.setVisibility(0)lzf.setVisibility(8)
            srzf.text=srzf.text.."3"
          end
          if fromjz=="Oct" then
            Octwb.text=q0(srzf.text)
            Binwb.text=Oct2Bin(srzf.text)
            Decwb.text=Bin2Dec(Binwb.text)
            Hexwb.text=Bin2Hex(Binwb.text)
          elseif fromjz=="Dec" then
            Decwb.text=q0(srzf.text)
            Binwb.text=Dec2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Hexwb.text=Bin2Hex(Binwb.text)
          elseif fromjz=="Hex" then
            Hexwb.text=q0(srzf.text)
            Binwb.text=Hex2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Decwb.text=Bin2Dec(Binwb.text)
          end
        end
      },
      {
        TextView,
        id="sr6",
        text="6",
        gravity="center",
        textSize="15.6sp",
        layout_width="fill",
        layout_weight="1",
        textColor=0xFF000000,
        Typeface=Typeface.DEFAULT_BOLD,
        onClick=function()
          if fromjz~="Bin" then
            srzf.setVisibility(0)lzf.setVisibility(8)
            srzf.text=srzf.text.."6"
          end
          if fromjz=="Oct" then
            Octwb.text=q0(srzf.text)
            Binwb.text=Oct2Bin(srzf.text)
            Decwb.text=Bin2Dec(Binwb.text)
            Hexwb.text=Bin2Hex(Binwb.text)
          elseif fromjz=="Dec" then
            Decwb.text=q0(srzf.text)
            Binwb.text=Dec2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Hexwb.text=Bin2Hex(Binwb.text)
          elseif fromjz=="Hex" then
            Hexwb.text=q0(srzf.text)
            Binwb.text=Hex2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Decwb.text=Bin2Dec(Binwb.text)
          end
        end
      },
      {
        TextView,
        id="sr9",
        text="9",
        gravity="center",
        textSize="15.6sp",
        layout_width="fill",
        layout_weight="1",
        textColor=0xFF000000,
        Typeface=Typeface.DEFAULT_BOLD,
        onClick=function()
          if fromjz~="Bin" and fromjz~="Oct" then
            srzf.setVisibility(0)lzf.setVisibility(8)
            srzf.text=srzf.text.."9"
          end
          if fromjz=="Dec" then
            Decwb.text=q0(srzf.text)
            Binwb.text=Dec2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Hexwb.text=Bin2Hex(Binwb.text)
          elseif fromjz=="Hex" then
            Hexwb.text=q0(srzf.text)
            Binwb.text=Hex2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Decwb.text=Bin2Dec(Binwb.text)
          end
        end
      },
      {
        TextView,
        id="scyw",
        text="DEL",
        gravity="center",
        textSize="15.6sp",
        layout_width="fill",
        layout_weight="1",
        textColor=0xFF68AFE5,
        Typeface=Typeface.DEFAULT_BOLD,
        onClick=function()
          srzf.text=srzf.text:sub(1,#srzf.text-1)
          if srzf.text=="" then
            Binwb.text="" Octwb.text="" Decwb.text="" Hexwb.text=""
            srzf.setVisibility(8)lzf.setVisibility(0)
          else
            if fromjz=="Bin" then
              Binwb.text=q0(srzf.text)
              Octwb.text=Bin2Oct(Binwb.text)
              Decwb.text=Bin2Dec(Binwb.text)
              Hexwb.text=Bin2Hex(Binwb.text)
            elseif fromjz=="Oct" then
              Octwb.text=q0(srzf.text)
              Binwb.text=Oct2Bin(srzf.text)
              Decwb.text=Bin2Dec(Binwb.text)
              Hexwb.text=Bin2Hex(Binwb.text)
            elseif fromjz=="Dec" then
              Decwb.text=q0(srzf.text)
              Binwb.text=Dec2Bin(srzf.text)
              Octwb.text=Bin2Oct(Binwb.text)
              Hexwb.text=Bin2Hex(Binwb.text)
            else
              Hexwb.text=q0(srzf.text)
              Binwb.text=Hex2Bin(srzf.text)
              Octwb.text=Bin2Oct(Binwb.text)
              Decwb.text=Bin2Dec(Binwb.text)
            end
          end
        end
      },
    },
    {
      LinearLayout,
      layout_height="fill",
      orientation="vertical",
      layout_width=(w-32*scale)/5,
      {
        TextView,
        id="srA",
        text="A",
        gravity="center",
        textSize="15.6sp",
        layout_width="fill",
        layout_weight="1",
        textColor=0xFFB2B2B2,
        Typeface=Typeface.DEFAULT_BOLD,
        onClick=function()
          if fromjz=="Hex" then
            srzf.setVisibility(0)lzf.setVisibility(8)
            srzf.text=srzf.text.."A"
            Hexwb.text=q0(srzf.text)
            Binwb.text=Hex2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Decwb.text=Bin2Dec(Binwb.text)
          end
        end
      },
      {
        TextView,
        id="srC",
        text="C",
        gravity="center",
        textSize="15.6sp",
        layout_width="fill",
        layout_weight="1",
        textColor=0xFFB2B2B2,
        Typeface=Typeface.DEFAULT_BOLD,
        onClick=function()
          if fromjz=="Hex" then
            srzf.setVisibility(0)lzf.setVisibility(8)
            srzf.text=srzf.text.."C"
            Hexwb.text=q0(srzf.text)
            Binwb.text=Hex2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Decwb.text=Bin2Dec(Binwb.text)
          end
        end
      },
      {
        TextView,
        id="srE",
        text="E",
        gravity="center",
        textSize="15.6sp",
        layout_width="fill",
        layout_weight="1",
        textColor=0xFFB2B2B2,
        Typeface=Typeface.DEFAULT_BOLD,
        onClick=function()
          if fromjz=="Hex" then
            srzf.setVisibility(0)lzf.setVisibility(8)
            srzf.text=srzf.text.."E"
            Hexwb.text=q0(srzf.text)
            Binwb.text=Hex2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Decwb.text=Bin2Dec(Binwb.text)
          end
        end
      },
      {
        TextView,
        layout_width="fill",
        layout_weight="1",
      },
    },
    {
      LinearLayout,
      layout_height="fill",
      orientation="vertical",
      layout_width=(w-32*scale)/5,
      {
        TextView,
        id="srB",
        text="B",
        gravity="center",
        textSize="15.6sp",
        layout_width="fill",
        layout_weight="1",
        textColor=0xFFB2B2B2,
        Typeface=Typeface.DEFAULT_BOLD,
        onClick=function()
          if fromjz=="Hex" then
            srzf.setVisibility(0)lzf.setVisibility(8)
            srzf.text=srzf.text.."B"
            Hexwb.text=q0(srzf.text)
            Binwb.text=Hex2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Decwb.text=Bin2Dec(Binwb.text)
          end
        end
      },
      {
        TextView,
        id="srD",
        text="D",
        gravity="center",
        textSize="15.6sp",
        layout_width="fill",
        layout_weight="1",
        textColor=0xFFB2B2B2,
        Typeface=Typeface.DEFAULT_BOLD,
        onClick=function()
          if fromjz=="Hex" then
            srzf.setVisibility(0)lzf.setVisibility(8)
            srzf.text=srzf.text.."D"
            Hexwb.text=q0(srzf.text)
            Binwb.text=Hex2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Decwb.text=Bin2Dec(Binwb.text)
          end
        end
      },
      {
        TextView,
        id="srF",
        text="F",
        gravity="center",
        textSize="15.6sp",
        layout_width="fill",
        layout_weight="1",
        textColor=0xFFB2B2B2,
        Typeface=Typeface.DEFAULT_BOLD,
        onClick=function()
          if fromjz=="Hex" then
            srzf.setVisibility(0)lzf.setVisibility(8)
            srzf.text=srzf.text.."F"
            Hexwb.text=q0(srzf.text)
            Binwb.text=Hex2Bin(srzf.text)
            Octwb.text=Bin2Oct(Binwb.text)
            Decwb.text=Bin2Dec(Binwb.text)
          end
        end
      },
      {
        TextView,
        layout_width="fill",
        layout_weight="1",
      },
    },
  },
}))
波纹方(Binwb,0xFFE0E0E0)波纹方(Octwb,0xFFE0E0E0)波纹方(Decwb,0xFFE0E0E0)波纹方(Hexwb,0xFFE0E0E0)
波纹(qksy,0xFF68AFE5)波纹(scyw,0xFF68AFE5)波纹(sr0,0xFF68AFE5)波纹(sr1,0xFF68AFE5)波纹(sr2,0xFF68AFE5)波纹(sr3,0xFF68AFE5)波纹(sr4,0xFF68AFE5)波纹(sr5,0xFF68AFE5)波纹(sr6,0xFF68AFE5)波纹(sr7,0xFF68AFE5)波纹(sr8,0xFF68AFE5)波纹(sr9,0xFF68AFE5)
fromjz="Dec"
seth(Binwb,geth(Binwb)+12*scale)seth(Octwb,geth(Octwb)+12*scale)seth(Decwb,geth(Decwb)+12*scale)seth(Hexwb,geth(Hexwb)+12*scale)
Binwb.text="" Octwb.text="" Decwb.text="" Hexwb.text=""
Binwb.setLineSpacing(1.3,1.3)Octwb.setLineSpacing(1.3,1.3)Decwb.setLineSpacing(1.3,1.3)Hexwb.setLineSpacing(1.3,1.3)
Binan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF9E9E9E,PorterDuff.Mode.SRC_ATOP))
Octan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF9E9E9E,PorterDuff.Mode.SRC_ATOP))
Decan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF68AFE5,PorterDuff.Mode.SRC_ATOP))
Hexan.getBackground().setColorFilter(PorterDuffColorFilter(0xFF9E9E9E,PorterDuff.Mode.SRC_ATOP))
function q0(str)
  for i=1,#str+1 do
    if i==#str+1 then
      str="0"
    elseif str:sub(i,i)~="0" then
      str=str:sub(i,#str)
      break
    end
  end
  return str
end
function xy2(str)
  val=""进=0
  for i=0,#str-1 do
    dg=str:sub(#str-i,#str-i)
    if dg*2+进<10 then
      val=tostring(tointeger(dg*2+进))..val
      进=0
     else
      if i~=#str-1 then
        val=tostring(tointeger(dg*2+进)):sub(2,2)..val
       else
        val=tostring(tointeger(dg*2+进))..val
      end
      进=tostring(tointeger(dg*2+进)):sub(1,1)
    end
  end
  return val
end
function c2(str)
  val="" 进=0
  for i=1,#str do
    dg=str:sub(i,i)+进
    if dg%2==1 then
      val=val..tointeger((dg-1)/2)
      进=10
     else
      val=val..tointeger(dg/2)
      进=0
    end
  end
  for i=1,#val do
    if val:sub(i,i)~="0" then
      val=val:sub(i,#val)
      break
    end
  end
  return val
end
function Bin2Oct(str)
  if #str<3 then
    for i=1,3-#str do
      str="0"..str
    end
   elseif #str%3~=0 then
    for i=1,3-#str%3 do
      str="0"..str
    end
  end
  octv=""
  for i=1,#str/3 do
    octv=octv..tointeger(str:sub(i*3-2,i*3-2)*4+str:sub(i*3-1,i*3-1)*2+str:sub(i*3,i*3))
  end
  return octv
end
function Bin2Dec(str)
  decv="0"
  for i=1,#str do
    if str:sub(i,i)=="1" then
      decv=xy2(decv)
      dec="" 进=0
      for i=0,#decv-1 do
        dg=decv:sub(#decv-i,#decv-i)
        if i==0 then
          if dg+1+进<10 then
            dec=tostring(tointeger(dg+1+进))..dec
            进=0
           else
            if i~=#decv-1 then
              dec=tostring(tointeger(dg+1+进)):sub(2,2)..dec
             else
              dec=tostring(tointeger(dg+1+进))..dec
            end
            进=tostring(tointeger(dg+1+进)):sub(1,1)
          end
         else
          if dg+进<10 then
            dec=tostring(tointeger(dg+进))..dec
            进=0
           else
            if i~=#decv-1 then
              dec=tostring(tointeger(dg+进)):sub(2,2)..dec
             else
              dec=tostring(tointeger(dg+进))..dec
            end
            进=tostring(tointeger(dg+进)):sub(1,1)
          end
        end
      end
      decv=dec
     else
      decv=xy2(decv)
    end
  end
  return decv
end
function Bin2Hex(str)
  if #str<4 then
    for i=1,4-#str do
      str="0"..str
    end
   elseif #str%4~=0 then
    for i=1,4-#str%4 do
      str="0"..str
    end
  end
  hexv=""
  for i=1,#str/4 do
    hexv=hexv..tostring(tointeger(str:sub(i*4-3,i*4-3)*8+str:sub(i*4-2,i*4-2)*4+str:sub(i*4-1,i*4-1)*2+str:sub(i*4,i*4))):gsub("10","A"):gsub("11","B"):gsub("12","C"):gsub("13","D"):gsub("14","E"):gsub("15","F")
  end
  return hexv
end
function Oct2Bin(str)
  binv=tostring(str):gsub("0","000"):gsub("1","001"):gsub("2","010"):gsub("3","011"):gsub("4","100"):gsub("5","101"):gsub("6","110"):gsub("7","111")
  if binv:find"1" then
    if binv:match("1(.+)")~=nil then
      return "1"..binv:match("1(.+)")
    else
      return "1"
    end
   else
    return "0"
  end
end
function Oct2Dec(str)
  return Bin2Dec(Oct2Bin(str))
end
function Oct2Hex(str)
  return Bin2Hex(Oct2Bin(str))
end
function Dec2Bin(str)
  binv=""
  for i=1,#str+1 do
    if i==#str+1 then
      str="0" binv="0"
    elseif str:sub(i,i)~="0" then
      str=str:sub(i,#str)
      break
    end
  end
  while str>"0" do
    if str:sub(#str,#str)%2==0 then
      binv="0"..binv
     else
      binv="1"..binv
    end
    str=c2(str)
  end
  return binv
end
function Dec2Oct(str)
  return Bin2Oct(Dec2Bin(str))
end
function Dec2Hex(str)
  return Bin2Hex(Dec2Bin(str))
end
function Hex2Bin(str)
  binv=string.upper(str):gsub("0","0000"):gsub("1","0001"):gsub("2","0010"):gsub("3","0011"):gsub("4","0100"):gsub("5","0101"):gsub("6","0110"):gsub("7","0111"):gsub("8","1000"):gsub("9","1001"):gsub("A","1010"):gsub("B","1011"):gsub("C","1100"):gsub("D","1101"):gsub("E","1110"):gsub("F","1111")
  if binv:find"1" then
    if binv:match("1(.+)")~=nil then
      return "1"..binv:match("1(.+)")
    else
      return "1"
    end
   else
    return "0"
  end
end
function Hex2Oct(str)
  return Bin2Oct(Hex2Bin(str))
end
function Hex2Dec(str)
  return Bin2Dec(Hex2Bin(str))
end
end)