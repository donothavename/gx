require"import"
import"imports"
function onTouchEvent(event)
  ac=event.action
  if ac==2 or ac==0 then
    x=event.X
    y=event.Y
    coe.setRotationX((activity.getHeight()-y)/30)
    coe.setRotationY(x/30)
  elseif ac==1 then
    coe.setRotationX(0)
    coe.setRotationY(0)
  end
end
task(2,function()
activity.setContentView(loadlayout({
  LinearLayout;
  orientation="vertical";
  layout_width="fill";
  layout_height="fill";
  id="coe",
  gravity="center";
  {
    TextView;
    id="dir";
    layout_width="fill";
    textColor="#0090FF";
    layout_height="7%h";
    textSize="25dp";
    gravity="center";
    text="南";
  };
  {
    ImageView,
    src="http://shp.qpic.cn/collector/2530648358/c9cfebe3-a191-49f3-80da-3675291ec297/0",
  },
  {
    LinearLayout;
    id="cors";
    orientation="vertical";
    layout_width="75%w";
    gravity="center";
    layout_height="75%w";
  },
  {
    LinearLayout,
    id="xsj",
    layout_width=0.6*w+48,
    layout_height=0.6*w+48,
    layout_marginTop=-(0.675*w+24),
    gravity="center",
    {
      ImageView,
      layout_width=30,
      layout_height=24,
      layout_gravity="top",
      ColorFilter=0xFF99ADC5,
      src="http://shp.qpic.cn/collector/2530648358/c9cfebe3-a191-49f3-80da-3675291ec297/0",
    },
  },
  {
    LinearLayout;
    layout_marginTop=-(0.6*w+24),
    layout_gravity="center";
    orientation="vertical";
    id="cor";
    layout_width="60%w";
    gravity="center",
    layout_height="60%w",
    {
      LinearLayout,
      id="kd",
      gravity="center",
      layout_width=0.6*w-40,
      layout_height=0.6*w-40,
      {
        LinearLayout,
        gravity="center",
        layout_gravity="center",
        orientation="vertical",
        {
          TextView,
          id="北",
          text="N",
          textSize="20dp",
          textColor=0xFF99ADC5,
        },
        {
          LinearLayout,
          orientation="horizontal",
          {
            LinearLayout,
            paddingRight=0.35*w,
            paddingTop=0.14*w,
            {
              TextView,
              id="西",
              text="W",
              gravity="center",
              textSize="20dp",
              layout_width="20dp",
              layout_height="20dp",
              textColor=0xFF99ADC5,
            },
          },
          {
            LinearLayout,
            paddingTop=0.14*w,
            {
              TextView,
              id="东",
              text="E",
              textSize="20dp",
              gravity="center",
              layout_width="25dp",
              layout_height="25dp",
              textColor=0xFF99ADC5,
            },
          },
        },
        {
          LinearLayout,
          paddingTop=0.14*w,
          {
            TextView,
            id="南",
            text="S",
            textSize="20dp",
            textColor=0xFF99ADC5,
          },
        }
      },
    },
  },
  {
    TextView;
    id="deg";
    layout_marginTop=-(0.04*h+0.3*w),
    textColor="0xff0088ff";
    layout_height="8%h";
    textSize="27dp";
    gravity="center";
    text="0°";
  };
}))
import "android.content.Context"
import "android.hardware.SensorManager"
import "android.hardware.SensorEventListener"
import "android.hardware.Sensor"
dirs=""
FPS=50
磁场=0
传感器 = activity.getSystemService(Context.SENSOR_SERVICE)
local 磁场传感器 = 传感器.getDefaultSensor(Sensor.TYPE_ORIENTATION)
传感器.registerListener(SensorEventListener({ 
  onSensorChanged=function(event) 
    磁场 = event.values[0]
  end,nil}), 磁场传感器, SensorManager.SENSOR_DELAY_NORMAL)
cors.setBackground(
LuaDrawable(
function(画布,画笔)
画笔.setColor(0xFF97ABC6)
画笔.setStyle(Paint.Style.STROKE)
画笔.setStrokeWidth(10)
画笔.setAntiAlias(true)
画笔2=Paint(画笔)
画笔2.setColor(0xff000000)
画笔2.setStyle(Paint.Style.STROKE)
画笔2.setStrokeWidth(10)
画笔2.setAntiAlias(true)
画笔3=Paint(画笔)
画笔3.setColor(0xFF747474)
画笔3.setStyle(Paint.Style.STROKE)
画笔3.setStrokeWidth(10)
画笔3.setAntiAlias(true)
画布.translate(画布.getWidth()/2,画布.getWidth()/2)
for i=0,900 do
  if i<=245 then
    画布.drawLine(0,0.375*w-4, 0,0.375*w, 画笔)
  elseif i<280 or (i>320 and i<565) then
    画布.drawLine(0,0.375*w-4, 0,0.375*w, 画笔2)
  elseif i>=565 and i<=600 then
    画布.drawLine(0,0.375*w-3, 0,0.375*w-1, 画笔3)
  end 
  画布.rotate(0.5,0,0)
end
end))
cor.setBackground(
LuaDrawable(
function(画布,画笔)
  画笔.setColor(0xFF747474)
  画笔.setStyle(Paint.Style.STROKE)
  画笔.setDither(true)
  画笔.setStrokeWidth(10)
  画笔.setAntiAlias(true)
  画布.translate(画布.getWidth()/2,画布.getWidth()/2)
  for i=0,900 do
    if i<=690 then
      画布.drawLine(0,0.3*w-3, 0,0.3*w-1, 画笔)
    end
  画布.rotate(0.5,0,0)
  end
end))
kd.setBackground(
LuaDrawable(
function(画布,画笔)
  画笔.setColor(0xFF99ADC5)
  画笔.setStyle(Paint.Style.STROKE)
  画笔.setDither(true)
  画笔.setStrokeWidth(3)
  画笔.setAntiAlias(true)
  画笔2=Paint(画笔)
  画笔2.setDither(true)
  画笔2.setColor(0xff000000)
  画笔2.setStyle(Paint.Style.STROKE)
  画笔2.setStrokeWidth(6.2)
  画笔2.setAntiAlias(true)
  画笔3=Paint(画笔)
  画笔3.setDither(true)
  画笔3.setAntiAlias(true)
  画笔3.setColor(0xff000000)
  画笔3.setStyle(Paint.Style.FILL)
  画笔3.setTextSize(15/360*w)
  画笔3.setStrokeWidth(2)
  画布.translate(画布.getWidth()/2,画布.getWidth()/2)
  count=180
  for i=0,180 do
    if i%45==0 then
      画布.drawLine(0,0.3*w-20,0,0.3*w-40,画笔)
    elseif i%15==0 then
      角度=i*2+180
      if 360-角度<0 then
        角度=角度-360
      end
      画布.drawText(tostring(角度),-30,0.3*w-60,画笔3)
      画布.drawLine(0,0.3*w-20,0,0.3*w-40,画笔2)
    else
      画布.drawLine(0,0.3*w-20,0,0.3*w-40,画笔2)
    end
  画布.rotate(360/count)
  end
end))
cors.setRotation(30)
cor.setRotation(188)
东.setRotation(90)
西.setRotation(-90)
南.setRotation(180)
kd.setRotation(-188)
tick=Ticker()
tick.Period=1000/FPS
tick.onTick=function()
  if 磁场>165 and 磁场<195 then
    dirs="南"
  elseif 磁场>195 and 磁场<255 then
    dirs="西南"
  elseif 磁场>255 and 磁场<285 then
    dirs="西"
  elseif 磁场>285 and 磁场<345 then
    dirs="西北"
  elseif 磁场>345 or 磁场<15 then
    dirs="北"
  elseif 磁场>15 and 磁场<75 then
    dirs="东北"
  elseif 磁场>75 and 磁场<105 then
    dirs="东"
  elseif 磁场>105 and 磁场<165 then
    dirs="东南"
  end
  dir.setText(dirs)
  cor.setRotation(360-磁场+188)
  xsj.setRotation(360-磁场)
  deg.setText(tostring(tointeger(磁场).."°"))
end
tick.start()
function onDestroy()
  tick.stop()
  传感器.unregisterListener(Listener);
end
end)