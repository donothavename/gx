require"import"
import"imports"
import"对话框"
task(2,function()
this.setContentView(loadlayout({
  LinearLayout,
  orientation="vertical",
  {
    LinearLayout,
    elevation="5dp",
    layout_width=w,
    orientation="vertical",
    backgroundColor=0xFF9AAEC7,
    {
      LinearLayout,
      layout_width=w,
      layout_height="56dp",
      orientation="horizontal",
      layout_marginTop=getStatusBarHeight(),
      {
        ImageView,
        padding="16dp",
        layout_width="56dp",
        layout_height="56dp",
        layout_gravity="center",
        src="http://shp.qpic.cn/collector/2530648358/6ce8ce2c-f0ac-4c11-b6c1-2c7daf86ac60/0",
        ColorFilter=0xffffffff,
        onClick=function()
          this.finish()
        end,
      },
      {
        LinearLayout,
        layout_height="56dp",
        layout_marginLeft="12dp",
        {
          TextView,
          textSize="18dp",
          textColor=0xffffffff,
          text="音乐搜索试听",
          layout_gravity="center",
        },
      },
    },
    {
      CardView,
      id="kddhk",
      elevation=0,
      radius="4dp",
      layout_height="48dp",
      layout_gravity="center",
      layout_width=w-28*scale,
      layout_marginTop="10dp",
      layout_marginBottom="10dp",
      CardBackgroundColor=0xffffffff,
      {
        LinearLayout,
        orientation="horizontal",
        {
          FrameLayout,
          layout_weight="1",
          layout_gravity="center",
          {
            LinearLayout,
            layout_width=w,
          },
          {
            EditText,
            id="gqm",
            singleLine=true,
            textSize="14sp",
            layout_width="fill",
            paddingLeft="16dp",
            textColor=0xff000000,
            backgroundColor=0xffffffff,
            hintTextColor=0xFFB6B6B6,
            hint="搜索歌手、歌名、专辑",
          },
        },
        {
          ImageView,
          id="cxgq",
          padding="11dp",
          layout_width="48dp",
          layout_height="48dp",
          layout_gravity="center",
          ColorFilter=0xFFB6B6B6,
          src="http://shp.qpic.cn/collector/2530648358/4801ab8c-3258-4d1b-aad2-40740e2456f8/0",
          onClick=function()
            zzbf=0 sscs=1 ssnr=gqm.text
            搜索音乐(ssnr,sscs)
            pagev.showPage(1)
            jxjz.setVisibility(0)jxjz.text="点击加载更多.."
          end,
        },
      },
    },
    {
      LinearLayout,
      layout_width=w,
      layout_height="54dp",
      layout_marginLeft="14dp",
      {
        LinearLayout,
        id="huatk",
        layout_gravity="center",
        orientation="horizontal",
        {
          FrameLayout,
          {
            CardView,
            id="huat",
            elevation=0,
            cardBackgroundColor=0xFFB6C3D3,
          },
          {
            LinearLayout,
            {
              LinearLayout,
              layout_gravity="center",
              onClick=function()
                pagev.showPage(0)
              end,
              {
                TextView,
                id="bfq",
                padding="6dp",
                text="播放器",
                paddingLeft="8dp",
                paddingRight="8dp",
              },
            },
            {
              LinearLayout,
              layout_gravity="center",
              onClick=function()
                pagev.showPage(1)
              end,
            {
              TextView,
              id="yylbwb",
              padding="6dp",
              text="音乐列表",
              paddingLeft="8dp",
              paddingRight="8dp",
              },
            },
          },
        },
      },
    },
  },
  {
    PageView,
    id="pagev",
    layout_width=w,
    layout_weight="1",
    backgroundColor=0xffffffff,
    pages={
      {
        LinearLayout,
        orientation="vertical",
        {
          CardView,
          radius="55dp",
          elevation="5dp",
          layout_width="110dp",
          layout_height="110dp",
          layout_gravity="center",
          layout_marginTop="5dp",
          layout_marginBottom="5dp",
          cardBackgroundColor=0xFFFFFFFF,
          {
            ImageView,
            id="yyuetp",
            layout_width="110dp",
            layout_height="110dp",
            layout_gravity="center",
            scaleType="centerCrop",
          },
        },
        {
          NestedScrollView,
          id="gcbj",
          layout_width=w,
          layout_height="fill",
          {
            LinearLayout,
            id="gcwblb",
            layout_width=w,
            orientation="vertical",
          },
        },
      },
      {
        NestedScrollView,
        id="yylbbj",
        layout_width="fill",
        layout_height="fill",
        {
          LinearLayout,
          orientation="vertical",
          {
            LinearLayout,
            padding="10dp",
            layout_width=w,
            paddingLeft="28dp",
            orientation="horizontal",
            {
              TextView,
              text="歌曲",
              textSize="16sp",
              layout_width=0.5*w,
              textColor=0xFF68AFE5,
            },
            {
              TextView,
              text="歌手",
              textSize="16sp",
              textColor=0xFF68AFE5,
            },
          },
          {
            TextView,
            layout_height="1dp",
            layout_width=0.95*w,
            layout_gravity="center",
            backgroundColor=0xFFF6F6F6,
          },
          {
            LinearLayout,
            id="yylb",
            orientation="vertical",
          },
          {
            TextView,
            id="jxjz",
            visibility=4,
            padding="10dp",
            layout_width=w,
            textColor=0xFF6E6E6E,
            onClick=function()
              if jxjz.text=="点击加载更多.." then
                sscs=sscs+1
                搜索音乐(ssnr,sscs)
              end
            end,
          }
        },
      },
    },
  },
  {
    LinearLayout,
    id="yybfkj",
    layout_width=w,
    paddingTop="14dp",
    orientation="vertical",
    backgroundColor=0xFFFFFFFF,
    {
      FrameLayout,
      layout_width=w,
      {
        ProgressBar,
        id="yyjd",
        max=1000,
        layout_gravity="center",
        layout_width=w-28*scale,
        style="?android:attr/progressBarStyleHorizontal",
      },
      {
        CardView,
        id="yyjdd",
        elevation=0,
        cardBackgroundColor=0xFF68AFE5,
      },
    },
    {
      LinearLayout,
      layout_width="fill",
      paddingLeft="14dp",
      paddingRight="14dp",
      orientation="horizontal",
      {
        TextView,
        id="nowt",
        text="00:00",
        textColor=0xFF6E6E6E,
      },
      {
        TextView,
        id="allt",
        text="00:00",
        gravity="right",
        layout_weight="1",
        textColor=0xFF6E6E6E,
      },
    },
    {
      LinearLayout,
      layout_width=w,
      layout_height="48dp",
      paddingBottom="14dp",
      orientation="horizontal",
      {
        ImageView,
        id="bffstp",
        padding="4dp",
        layout_width=w/5,
        layout_gravity="center",
        ColorFilter=0xFF6E6E6E,
        src="http://shp.qpic.cn/collector/2530648358/5e4683b4-5108-421d-9212-3276ae09ceb5/0",
        onClick=function()
          if bffs=="列表循环" then
            bffs="随机播放"
            bffstp.setImageBitmap(loadbitmap("http://shp.qpic.cn/collector/2530648358/41fa19e1-5a52-4bc1-8f08-3a14de50f23f/0"))
          elseif bffs=="随机播放" then
            bffs="单曲循环"
            bffstp.setImageBitmap(loadbitmap("http://shp.qpic.cn/collector/2530648358/4fccc4d5-2fde-49f3-a4a5-1f5d446a074a/0"))
          else
            bffs="列表循环"
            bffstp.setImageBitmap(loadbitmap("http://shp.qpic.cn/collector/2530648358/5e4683b4-5108-421d-9212-3276ae09ceb5/0"))
          end
          提示(bffs)
        end,
      },
      {
        ImageView,
        id="systp",
        layout_width=w/5,
        layout_gravity="center",
        ColorFilter=0xFF6E6E6E,
        src="http://shp.qpic.cn/collector/2530648358/458de12d-a256-4da1-9f84-f750f821496d/0",
        onClick=function()
          if zzbf~=0 then
            if zzbf>1 then
              播放音乐(zzbf-1,链接id[zzbf-1])
            else
              播放音乐(#音乐id,链接id[#音乐id])
            end
          end
        end,
      },
      {
        ImageView,
        id="bfzttp",
        layout_width=w/5,
        layout_gravity="center",
        ColorFilter=0xFF6E6E6E,
        src="http://shp.qpic.cn/collector/2530648358/600d320d-4b93-43f0-9242-d5595f7b72f0/0",
        onClick=function()
          if mediaPlayer then
            if mediaPlayer.isPlaying() then
              mediaPlayer.pause()
              bfzttp.setImageBitmap(loadbitmap("http://shp.qpic.cn/collector/2530648358/600d320d-4b93-43f0-9242-d5595f7b72f0/0"))
            else
              mediaPlayer.start()
              bfzttp.setImageBitmap(loadbitmap("http://shp.qpic.cn/collector/2530648358/f83b6eca-d92b-460a-8bd6-e7ae4177874e/0"))
            end
          end
        end,
      },
      {
        ImageView,
        id="xystp",
        layout_width=w/5,
        layout_gravity="center",
        ColorFilter=0xFF6E6E6E,
        src="http://shp.qpic.cn/collector/2530648358/6fb35fa9-94e1-4ea3-806a-9d7337cffb88/0",
        onClick=function()
          if zzbf~=0 then
            if zzbf<#音乐id then
              播放音乐(zzbf+1,链接id[zzbf+1])
            else
              播放音乐(1,链接id[1])
            end
          end
        end,
      },
      {
        ImageView,
        id="xztp",
        padding="6dp",
        layout_width=w/5,
        layout_gravity="center",
        ColorFilter=0xFF6E6E6E,
        src="http://shp.qpic.cn/collector/2530648358/e6a00e91-f87a-4f3f-b321-a5b0f43c0495/0",
        onClick=function()
          if zzbf~=0 then
            Http.get("http://vip.muyl.vip/template/JOELEO/asset/inc/api.php?callback=jQuery1110049092228126606385_1570265724024&types=url&id="..链接id[zzbf].."&source=netease",nil,"utf8",nil,function(code,content)
              url2=content:match("jQuery1110049092228126606385_1570265724024(.+)")
              url2="["..url2:sub(2,#url2-2).."]"
              json_o=JSON.decode(url2)
              for i,v in ipairs(json_o) do
                if v.url~="" then
                  下载(v.url,"/storage/emulated/0/Download/QQBiD/"..音乐名称[zzbf].." "..歌手[zzbf]..".mp3")
                else
                  提示"获取链接失败"
                end
              end
            end)
          end
        end,
      },
    },
  },
}))
bffs="列表循环"
import "android.media.MediaPlayer"
local function 播放音乐(i,url)
  zzbf=i collectgarbage("collect")
  for i=1,#音乐id do
    loadstring("return 音乐"..i)().setTextColor(0xFF000000)
    loadstring("return 歌名"..i)().setTextColor(0xFF000000)
    loadstring("return 歌手"..i)().setTextColor(0xFF000000)
  end
  loadstring("return 音乐"..i)().setTextColor(0xFF68AFE5)
  loadstring("return 歌名"..i)().setTextColor(0xFF68AFE5)
  loadstring("return 歌手"..i)().setTextColor(0xFF68AFE5)
  Http.get("http://vip.muyl.vip/template/JOELEO/asset/inc/api.php?callback=jQuery1110049092228126606385_1570265724024&types=url&id="..url.."&source=netease",nil,"utf8",nil,function(code,content)
    url=content:match("jQuery1110049092228126606385_1570265724024(.+)")
    url="["..url:sub(2,#url-2).."]"
    json_o=JSON.decode(url)
    for n,v in ipairs(json_o) do
      if mediaPlayer then
        mediaPlayer.stop()
        mediaPlayer=nil
      end
      if v.url~="" then
        collectgarbage("collect")
        获取音乐图片(图片id[i])
        gcbj.scrollTo(0,0)
        collectgarbage("collect")
        thread(获取歌词,歌词id[i])
        collectgarbage("collect")
        mediaPlayer=MediaPlayer()
        mediaPlayer.reset()
        mediaPlayer.setDataSource(v.url)
        mediaPlayer.prepare()
        collectgarbage("collect")
        mediaPlayer.start()
        collectgarbage("collect")
        bfzttp.setImageBitmap(loadbitmap("http://shp.qpic.cn/collector/2530648358/f83b6eca-d92b-460a-8bd6-e7ae4177874e/0"))
        mediaPlayer.setOnCompletionListener({onCompletion=function()
          collectgarbage("collect")
          if zzbf~=0 then
            if bffs=="列表循环" then
              if zzbf<#音乐id then
                播放音乐(zzbf+1,链接id[zzbf+1])
              else
                播放音乐(1,链接id[1])
              end
            elseif bffs=="随机播放" then
              zzbf=math.random(1,#音乐id)
              播放音乐(zzbf,链接id[zzbf])
            else
              播放音乐(zzbf,链接id[zzbf])
            end
          end
        end})
        song_time=mediaPlayer.getDuration()
        分=tostring(tointeger(song_time/1000/60))
        if #分==1 then
          分="0"..分
        end
        秒=tostring(tointeger((song_time/1000)%60))
        if #秒==1 then
          秒="0"..秒
        end
        allt.text=分..":"..秒
      else
        提示"播放失败，自动播放下一首"
        if zzbf~=0 then
          if zzbf<#音乐id then
            播放音乐(zzbf+1,链接id[zzbf+1])
          else
            播放音乐(1,链接id[1])
          end
        end
      end
    end
    if 分 then
      歌曲时间[i]=分..":"..秒
      分=nil 秒=nil
    end
  end)
end
function 获取音乐图片(pic)
  collectgarbage("collect")
  Http.get("http://vip.muyl.vip/template/JOELEO/asset/inc/api.php?callback=jQuery1110049092228126606385_1570265724024&types=pic&id="..pic.."&source=netease",nil,"utf8",nil,function(code,content)
    if code==200 then
      pic=content:match("jQuery1110049092228126606385_1570265724024(.+)")
      pic="["..pic:sub(2,#pic-2).."]"
      json_o=JSON.decode(pic)
      for i,v in ipairs(json_o) do
        yyuetp.setImageBitmap(loadbitmap(v.url))
      end
    end
  end)
end
function 添加歌词布局(歌词布局)
  collectgarbage("collect")
  if gcfbj then
    gcfbj.setVisibility(8)
  end
  gcwblb.addView(loadlayout(loadstring("return "..歌词布局)()))
end
function 获取各行歌词高度(n)
  collectgarbage("collect")
  歌词高度={}
  for i=1,n do
    table.insert(歌词高度,loadstring("return fbj歌词"..i)().getHeight())
  end
end
function gdsj()end
function 返回滚动事件(滚动事件)
  collectgarbage("collect")
  gdsj=loadstring("return function()pcall(function()"..滚动事件.."end)end")()
end
function 获取歌词(lyric)
  歌词适配布局=[[{
  LinearLayout,
  id="fbj歌词id",
  padding="5dp",
  layout_width=w,
  layout_gravity="center",
  paddingLeft="14dp",
  paddingRight="14dp",
  {
    TextView,
    id="歌词id",
    text="文字",
    gravity="center",
    textSize="16sp",
    layout_width="fill",
    textColor=0xff000000,
    },
  },
]]
require"import"
  import "com.androlua.Http"
  Http.get("http://vip.muyl.vip/template/JOELEO/asset/inc/api.php?callback=jQuery111006245952305442848_1570020593174&types=lyric&id="..lyric.."&source=netease",nil,"utf8",nil,function(code,content)
    collectgarbage("collect")
    歌词=content:match("jQuery111006245952305442848_1570020593174(.+)")
    歌词="["..歌词:sub(2,#歌词-2).."]"
    JSON=import "cjson"
    json_o=JSON.decode(歌词)
    for i,v in pairs(json_o) do
      歌词=""
      for i=1,#v.lyric do
        if v.lyric:sub(i,i)=="[" then
          歌词=歌词..'"'
         elseif v.lyric:sub(i,i)=="]" then
           if v.lyric:sub(i+1,i+1)=="[" then
             歌词=歌词..'","\n'
           else
             歌词=歌词..'","'
           end
         else
          歌词=歌词..v.lyric:sub(i,i)
        end
      end
      if 歌词~="" then
        歌词='"00:'..(歌词:gsub("\n",'",')..'"'):match('"00:(.+)')
        gc=歌词:gmatch('"(.-)"')
        local n=0 歌词时间={} 歌词={} 歌词布局=""
        for i in gc do
          n=n+1
          if n%2==1 then
            table.insert(歌词时间,tointeger(tostring(i:gsub(":","")):sub(1,2)*60)+tointeger(tostring(i:gsub(":","")):sub(3,4)))
           else
            table.insert(歌词,i)
          end
        end
      end
    end
    if 歌词~="" then
      for i=1,#歌词 do
        歌词布局=歌词布局..歌词适配布局:gsub("歌词id","歌词"..i):gsub("文字",歌词[i])
      end
      歌词布局=[[{
        LinearLayout,
        id="gcfbj",
        layout_width=w,
        gravity="center",
        layout_height="fill",
        orientation="vertical",
      ]]..歌词布局.."}"
      call('添加歌词布局',歌词布局)
      task(500,function()
        call('获取各行歌词高度',#歌词时间)
        task(100,function()
          歌词高度=activity.get("歌词高度")
          滚动事件=""
          for i=1,#歌词时间 do
            y=0
           for n=1,i-1 do
              y=y+歌词高度[n]
            end
            y=y-activity.get("gcbjh")/2+歌词高度[i]/2
            if i==#歌词时间 then
              滚动事件=滚动事件.." time=play_time/1000 if time>="..tostring(歌词时间[i]).." then if not ckgc then gcbj.smoothScrollTo(0,"..y..")end task(50,function()for i=1,"..#歌词时间.." do loadstring('return 歌词'..i)().setTextColor(0xFF000000)end 歌词"..i..".setTextColor(0xFF68AFE5)end) end "
            else
              滚动事件=滚动事件.." time=play_time/1000 if time>="..tostring(歌词时间[i]).." and time<"..tostring(歌词时间[i+1]).." then if not ckgc then gcbj.smoothScrollTo(0,"..y..")end task(50,function()for i=1,"..#歌词时间.." do loadstring('return 歌词'..i)().setTextColor(0xFF000000)end 歌词"..i..".setTextColor(0xFF68AFE5)end) end "
            end
          end
          call('返回滚动事件',滚动事件)
        end)
      end)
    else
      call('添加歌词布局','{TextView,id="gcfbj",gravity="center",text="无歌词",textSize="16sp",layout_width=w,padding="14dp",textColor=0xff000000}')
      call('获取各行歌词高度',0)
      call('返回滚动事件',"")
    end
  end)
end
local function 添加布局(i,id,name,artist,album,url)
  local 布局={
    LinearLayout,
    id="音乐列表"..i,
    layout_width=w,
    orientation="vertical",
    backgroundColor=0xFFFFFFFF,
    onClick=function()
      collectgarbage("collect")
      播放音乐(i,url)
    end,
    {
      LinearLayout,
      padding="10dp",
      layout_width=w,
      orientation="horizontal",
      {
        TextView,
        id="音乐"..i,
        textSize="16sp",
        text=tostring(i),
        paddingRight="10dp",
        textColor=0xFF000000,
      },
      {
        TextView,
        id="歌名"..i,
        maxLines=1,
        textSize="16sp",
        text=tostring(name),
        layout_width=0.5*w,
        textColor=0xff000000,
      },
      {
        TextView,
        id="歌手"..i,
        maxLines=1,
        textSize="16sp",
        text=tostring(artist),
        layout_weight="1",
        textColor=0xff000000,
      },
      {
        CardView,
        radius="10dp",
        elevation="1dp",
        layout_width="20dp",
        layout_height="20dp",
        layout_gravity="center",
        {
          ImageView,
          id="图片"..i,
          padding="1dp",
          elevation="1dp",
          layout_width="20dp",
          layout_height="20dp",
          layout_gravity="center",
          src="http://shp.qpic.cn/collector/2530648358/157972bd-3f2d-46c0-bb0f-676a87634525/0",
          onClick=function()
            对话框()
            .设置消息("歌名："..name.."\n\n歌手："..artist.."\n\n专辑："..album.."\n\n时长："..歌曲时间[i])
            .设置中立按钮("关闭")
            .设置积极按钮("下载",function()
              Http.get("http://vip.muyl.vip/template/JOELEO/asset/inc/api.php?callback=jQuery1110049092228126606385_1570265724024&types=url&id="..url.."&source=netease",nil,"utf8",nil,function(code,content)
                url2=content:match("jQuery1110049092228126606385_1570265724024(.+)")
                url2="["..url2:sub(2,#url2-2).."]"
                json_o=JSON.decode(url2)
                for i,v in ipairs(json_o) do
                  if v.url~="" then
                    下载(v.url,"/storage/emulated/0/Download/QQBiD/"..name.." "..artist..".mp3")
                  else
                    提示"获取链接失败"
                  end
                end
              end)
            end)
            .显示()
            retext.setPadding(24*scale,24*scale,24*scale,0)
          end,
        },
      },
    },
    {
      TextView,
      layout_width=0.95*w,
      layout_height="1dp",
      layout_gravity="center",
      backgroundColor=0xFFF6F6F6,
    },
  }
  return 布局
end
function 搜索音乐(name,sscs)
  collectgarbage("collect")
  if sscs<=5 then
    url="http://vip.muyl.vip/template/JOELEO/asset/inc/api.php?callback=jQuery1110006499043610914579_1570024239567&types=search&count="..20*sscs.."&source=netease&pages=1&name="..name
  else
    url="http://vip.muyl.vip/template/JOELEO/asset/inc/api.php?callback=jQuery111009825395460520832_1570295814097&types=search&count=20&source=netease&pages="..sscs.."&name="..name
  end
  Http.get(url,nil,"utf8",nil,function(code,content)
    if code==200 then
      if 音乐id then
        for i=1,#音乐id do
          loadstring("return 音乐列表"..i)().setVisibility(8)
        end
      end
      if sscs<=5 then
        音乐id={}音乐名称={}歌手={}图片id={}歌词id={}链接id={}专辑={}歌曲时间={}
        音乐列表=content:match("jQuery1110006499043610914579_1570024239567(.+)")
      else
        音乐列表=content:match("jQuery111009825395460520832_1570295814097(.+)")
      end
      音乐列表=音乐列表:sub(3,#音乐列表-3)
      音乐列表="["..音乐列表.."]"
      JSON=import "cjson"
      json_o=JSON.decode(音乐列表)
      for i,v in ipairs(json_o) do
        歌曲时间[i]="00:00" table.insert(音乐id,tostring(tointeger(v.id))) table.insert(音乐名称,v.name) table.insert(图片id,v.pic_id) table.insert(歌词id,tostring(tointeger(v.lyric_id))) table.insert(链接id,tostring(tointeger(v.url_id))) table.insert(专辑,v.album) table.insert(歌手,v.artist[1])
      end
      for i=1,#音乐id do
        布局=添加布局(i,音乐id[i],音乐名称[i],歌手[i],专辑[i],链接id[i])
        yylb.addView(loadlayout(布局))
        波纹方(loadstring("return 音乐列表"..i)(),0xFFE0E0E0)
        波纹(loadstring("return 图片"..i)(),0xFFE0E0E0)
      end
      if zzbf~=0 then
        for i=1,#音乐id do
          loadstring("return 音乐"..i)().setTextColor(0xFF000000)
          loadstring("return 歌名"..i)().setTextColor(0xFF000000)
          loadstring("return 歌手"..i)().setTextColor(0xFF000000)
        end
        loadstring("return 音乐"..zzbf)().setTextColor(0xFF68AFE5)
        loadstring("return 歌名"..zzbf)().setTextColor(0xFF68AFE5)
        loadstring("return 歌手"..zzbf)().setTextColor(0xFF68AFE5)
      end
      if #音乐id<20*sscs then
        jxjz.text="全部加载完了"
      end
    end
  end)
end
task(5,function()gcbjh=gcbj.getHeight()end)
波纹(bffstp,0xFFE2E2E2)波纹(systp,0xFFE2E2E2)波纹(bfzttp,0xFFE2E2E2)波纹(xystp,0xFFE2E2E2)波纹(xztp,0xFFE2E2E2)颜色(gqm,0xFF60ACE5)波纹(cxgq,0xFFE2E2E2)波纹方(jxjz,0xFFE0E0E0)
seth(yyjdd,geth(yyjd)/1.25)setw(yyjdd,geth(yyjd)/1.25)yyjdd.setRadius(geth(yyjd)/2.5)
yyjddx=14*scale-geth(yyjd)/2.5
yyjdd.setTranslationX(yyjddx)yyjdd.setTranslationY((geth(yyjd)-geth(yyjd)/1.25)/2)
local yyjdw=w-28*scale
yyjd.ProgressDrawable.setColorFilter(PorterDuffColorFilter(0xFF68AFE5,PorterDuff.Mode.SRC_ATOP))
gqm.setOnKeyListener({
  onKey=function(view,code,event)
    if code==66 then
      activity.getSystemService(Context.INPUT_METHOD_SERVICE).hideSoftInputFromWindow(gqm.getWindowToken(),0)
      zzbf=0 sscs=1 ssnr=gqm.text
      搜索音乐(ssnr,sscs)
      pagev.showPage(1)
      jxjz.setVisibility(0)jxjz.text="点击加载更多.."
    end
  end
})
音乐定时器=Ticker()
音乐定时器.Period=400
音乐定时器.onTick=function()
  pcall(function ()
    if mediaPlayer.isPlaying() then
      play_time=mediaPlayer.getCurrentPosition()
      gdsj()
      if not tzyyjd then
        yyjd.setProgress(play_time/song_time*1000)
        yyjdd.setTranslationX(yyjddx+play_time/song_time*yyjdw)
      end
      local 分=tostring(tointeger(play_time/1000/60))
      if #分==1 then
        分="0"..分
      end
      local 秒=tostring(tointeger((play_time/1000)%60))
      if #秒==1 then
        秒="0"..秒
      end
      nowt.text=分..":"..秒
    end
  end)
end
音乐定时器.start()
gcbj.onTouch=function(v,e)
  if e.action==1 then
    ckgc=nil
  else
    ckgc=true
  end
end
yyjd.onTouch=function(v,e)
  if e.action==0 then
    tzyyjd=true
  elseif e.action==2 then
    if e.getX()>=0 and e.getX()<=yyjdw and mediaPlayer then
      yyjd.setProgress(e.getX()/yyjdw*1000)
      yyjdd.setTranslationX(yyjddx+e.getX())
    end
  else
    if mediaPlayer then
      local 分=tostring(tointeger(((e.getX()/yyjdw)*song_time/1000)/60))
      if #分==1 then
        分="0"..分
      end
      local 秒=tostring(tointeger(((e.getX()/yyjdw)*song_time/1000)%60))
      if #秒==1 then
        秒="0"..秒
      end
      nowt.text=分..":"..秒
      mediaPlayer.seekTo((e.getX()/yyjdw)*song_time)
    end
    tzyyjd=nil
  end
  return true
end
setw(huat,getw(bfq))seth(huat,geth(bfq))huat.setRadius(geth(bfq)/2)
local kuan=getw(bfq)
pagev.setOnPageChangeListener(PageView.OnPageChangeListener{
  onPageScrolled=function(a,b,c)
    ckgc=nil
    huat.setX(kuan*(b+a))
    if a~=1 then
      setw(huat,getw(bfq)-b*(getw(bfq)-getw(yylbwb)))
    end
    if c==0then
      if a==0then
        bfq.setTextColor(0xFFFFFFFF)
        yylbwb.setTextColor(0xFFDEDEDE)
       else
        bfq.setTextColor(0xFFDEDEDE)
        yylbwb.setTextColor(0xFFFFFFFF)
      end
    end
  end
})
end)