require"import"
import"imports"
task(2,function()
activity.setContentView(loadlayout({
  LinearLayout,
  orientation="vertical",
  backgroundColor=0xFF9AAEC7,
  {
    LinearLayout,
    layout_width=w,
    layout_height="56dp",
    backgroundColor=0xFF9AAEC7,
    layout_marginTop=getStatusBarHeight(),
    {
      TextView,
      textSize="18dp",
      text="摩斯电码",
      textColor=0xffffffff,
      layout_gravity="center",
      layout_marginLeft="16dp",
    },
  },
  {
    LinearLayout,
    layout_width=w,
    orientation="vertical",
    backgroundColor=0xffffffff,
    layout_height=h-getStatusBarHeight()-56*scale,
    {
      EditText,
      id="srwb",
      gravity="top",
      padding="16dp",
      layout_width="fill",
      textColor=0xff000000,
      hintTextColor=0xffa1a1a1,
      backgroundColor=0xffffffff,
      layout_height=(h-149*scale-getStatusBarHeight())/2,
      hint="请输入需要转换成摩斯电码的文本（不支持中文）",
    },
    {
      LinearLayout,
      padding="24dp",
      layout_width=w,
      orientation="horizontal",
      backgroundColor=0xFFF5F5F5,
      {
        CardView,
        elevation=0,
        radius="22.5dp",
        layout_weight="1",
        layout_height="45dp",
        layout_marginRight="12dp",
        cardBackgroundColor=0xFF9AAEC7,
        {
          TextView,
          id="hyzmw",
          gravity="center",
          layout_width="fill",
          text="还原至明文",
          layout_height="fill",
          textColor=0xffffffff,
          onClick=function()
            电码文本=""
            if srwb.text~=""then
              for i=1,#srwb.text do
                if string.byte(srwb.text,i)==46 then
                  电码文本=电码文本.."点"
                elseif string.byte(srwb.text,i)==45 then
                  电码文本=电码文本.."杠"
                else
                  电码文本=电码文本..srwb.text:sub(i,i)
                end
              end
              if 电码文本:sub(#电码文本,#电码文本)~=" " then
                电码文本=电码文本.." "
              end
              scwb.text=电码文本:sub(2,#电码文本):gsub("/"," "):gsub("杠杠杠点点点 ",":"):gsub("杠杠点点杠杠 ",","):gsub("杠点杠点杠点 ",";"):gsub("点点杠杠点点 ","?"):gsub("杠点杠点杠杠 ","!"):gsub("点点杠杠点杠 ","_"):gsub("点杠点点杠点 ",'"'):gsub("点杠杠点杠点 ","@"):gsub("点杠杠杠杠点 ","'"):gsub("点杠点杠点杠 ","."):gsub("杠点杠杠点杠 ",")"):gsub("杠点点点杠 ","="):gsub("杠杠杠杠杠 ","0"):gsub("点杠杠杠杠 ","1"):gsub("点点杠杠杠 ","2"):gsub("点点点杠杠 ","3"):gsub("点点点点杠 ","4"):gsub("点点点点点 ","5"):gsub("杠点点点点 ","6"):gsub("杠杠点点点 ","7"):gsub("杠杠杠点点 ","8"):gsub("杠杠杠杠点 ","9"):gsub("杠点杠杠点 ","("):gsub("点杠杠点 ","p"):gsub("杠杠点 ","g"):gsub("杠点杠点 ","c"):gsub("杠点点杠点 ","/"):gsub("点点杠点 ","f"):gsub("点杠点 ","r"):gsub("杠点 ","n"):gsub("杠点点点 ","b"):gsub("点点点点 ","h"):gsub("点杠点点 ","l"):gsub("杠杠点点 ","z"):gsub("杠点点 ","d"):gsub("点点点 ","s"):gsub("点点 ","i"):gsub("杠点杠杠 ","y"):gsub("点杠杠 ","w"):gsub("点杠杠杠 ","j"):gsub("杠杠杠 ","o"):gsub("杠杠 ","m"):gsub("杠杠点杠 ","q"):gsub("杠点杠 ","k"):gsub("点点点杠 ","v"):gsub("杠点点杠 ","x"):gsub("点点杠 ","u"):gsub("点杠 ","a"):gsub("点 ","e"):gsub("杠 ","t")
            else
              提示"请输入文本.."
            end
          end,
        },
      },
      {
        CardView,
        elevation=0,
        radius="22.5dp",
        layout_weight="1",
        layout_height="45dp",
        layout_gravity="center",
        layout_marginLeft="12dp",
        cardBackgroundColor=0xFF68AFE5,
        {
          TextView,
          id="zwmsdm",
          text="转为摩斯电码",
          textColor=0xffffffff,
          gravity="center",
          layout_width="fill",
          layout_height="fill",
          onClick=function()
          正常文本=""
            if srwb.text~=""then
              for i=1,#srwb.text do
                if string.byte(srwb.text,i)==46 then
                  正常文本=正常文本..".-.-.- "
                elseif string.byte(srwb.text,i)==40 then
                  正常文本=正常文本.."-.--. "
                elseif string.byte(srwb.text,i)==41 then
                  正常文本=正常文本.."-.--.- "
                else
                  正常文本=正常文本..srwb.text:sub(i,i)
                end
              end
              scwb.text=" "..string.lower(正常文本):gsub("a",".- "):gsub("b","-... "):gsub("c","-.-. "):gsub("d","-.. "):gsub("e",". "):gsub("f","..-. "):gsub("g","--. "):gsub("h",".... "):gsub("i",".. "):gsub("j",".--- "):gsub("k","-.- "):gsub("l",".-.. "):gsub("m","-- "):gsub("n","-. "):gsub("o","--- "):gsub("p",".--. "):gsub("q","--.- "):gsub("r",".-. "):gsub("s","... "):gsub("t","- "):gsub("u","..- "):gsub("v","...- "):gsub("w",".-- "):gsub("x","-..- "):gsub("y","-.-- "):gsub("z","--.. "):gsub("1",".---- "):gsub("2","..--- "):gsub("3","...-- "):gsub("4","....- "):gsub("5","..... "):gsub("6","-.... "):gsub("7","--... "):gsub("8","---.. "):gsub("9","----. "):gsub("0","----- "):gsub(":","---... "):gsub(",","--..-- "):gsub(";","-.-.-. "):gsub("?","..--.. "):gsub("=","-...- "):gsub("'",".----. "):gsub("/","-..-. "):gsub("!","-.-.-- "):gsub("_","..--.- "):gsub('"',".-..-. "):gsub("@",".--.-. ")
            else
              提示"请输入文本.."
            end
          end,
        },
      },
    },
    {
      EditText,
      id="scwb",
      gravity="top",
      padding="16dp",
      layout_width=w,
      hint="内容输出..",
      layout_weight="1",
      backgroundColor=0x0,
      textColor=0xff000000,
      hintTextColor=0xffa1a1a1,
    },
    {
      ImageView,
      id="fznr",
      padding="16dp",
      layout_width="56dp",
      layout_height="56dp",
      layout_gravity="right",
      src="http://shp.qpic.cn/collector/2530648358/936bf7ca-d0f1-4f81-b0d1-ddd28b7255a3/0",
      onClick=function()
        复制文本(scwb.text)
        提示"复制完成"
      end,
    },
  },
}))
波纹(fznr,0xFFE2E2E2)波纹(hyzmw,0xFF92A4BC)波纹(zwmsdm,0xFF63A5D7)
颜色(scwb,0xFF68AFE5)颜色(srwb,0xFF68AFE5)
end)