Http.get("https://sharechain.qq.com/dc2f311c2b314a5edc35f3d9204964f7",nil,"utf8",nil,function(code,content)
  if code==200 then
    content=content:match("\"html_content\":(.-),"):gsub("\\u003C/?.-%>",""):gsub("\\\\","&revs;"):gsub("\\n","\n"):gsub("&nbsp;"," "):gsub("&lt;","<"):gsub("&gt;",">"):gsub("&quot;","\""):gsub("&apos;","'"):gsub("&revs;","\\"):gsub("&amp;","&");
    if content:match("【工具箱】(.-)【工具箱】")>"1.3.9" then
      fbj.addView(loadlayout({
        LinearLayout,
        id="bjbj",
        layout_width=w,
        layout_height=h,
        backgroundColor=0x80000000,
        {
          CardView,
          id="bjkp",
          radius="10dp",
          layout_width=w,
          layout_gravity="bottom",
          layout_marginBottom="-10dp",
          cardBackgroundColor=0xFFFFFFFF,
          {
            LinearLayout,
            layout_width=w,
            orientation="vertical",
            {
              LinearLayout,
              layout_width=w,
              paddingTop="24dp",
              paddingLeft="32dp",
              paddingRight="24dp",
              orientation="horizontal",
              {
                TextView,
                textSize="17sp",
                layout_weight="1",
                text="检测到更新",
                layout_gravity="center",
                textColor=0xFF000000,
                Typeface=Typeface.DEFAULT_BOLD,
              },
              {
                ImageView,
                id="gbjcdgxbj",
                padding="15dp",
                layout_width="55dp",
                layout_height="55dp",
                layout_gravity="center",
                ColorFilter=0xFF707070,
                src="http://shp.qpic.cn/collector/2530648358/6a4d61ec-a43b-454e-87c7-3a471e95e51a/0",
                onClick=function()
                  关闭()
                end,
              },
            },
            {
              LinearLayout,
              layout_height="7dp",
            },
            {
              LinearLayout,
              layout_width=w,
              paddingLeft="32dp",
              paddingRight="32dp",
              orientation="vertical",
              {
                TextView,
                textSize="12sp",
                paddingLeft="2dp",
                text="更新内容：",
                textColor=0xFF68AFE5,
              },
              {
                TextView,
                textSize="17sp",
                textColor=0xFF000000,
                Typeface=Typeface.DEFAULT_BOLD,
                text=content:match("【工具箱内容】(.-)【工具箱内容】"),
              },
            },
            {
              LinearLayout,
              gravity="right",
              layout_width=w,
              paddingTop="17dp",
              paddingRight="32dp",
              paddingBottom="43dp",
              {
                LinearLayout,
                layout_height="46dp",
                {
                  CardView,
                  radius="5dp",
                  layout_gravity="center",
                  cardBackgroundColor=0xFF68AFE5,
                  {
                    TextView,
                    text="更新",
                    gravity="center",
                    layout_height="36dp",
                    layout_width="87.5dp",
                    textColor=0xFFFFFFFF,
                    onClick=function()
                      关闭()
                      更新动画={
                        LinearLayout;
                        id='gxtx',
                        layout_width='fill';
                        layout_height='fill';
                        backgroundColor=0x00;
                        Gravity="center",
                        {
                          CardView;
                          CardElevation='10';
                          layout_width='200dp';
                          layout_height='200dp';
                          radius='100dp';
                          CardBackgroundColor=0xFF68AFE5;
                          {
                            FrameLayout,
                            layout_width='fill',
                            layout_height='fill',
                            {
                              WaveView;
                              layout_height="fill",
                              layout_width="fill",
                              id="wave",
                            };
                            {
                              TextView,
                              id='jd',
                              text="准备中...",
                              textSize='20sp',
                              layout_gravity='center',
                            },
                          },
                        };
                      };
                      gxdh=PopupWindow(loadlayout(更新动画))
                      gxdh.setFocusable(false)
                      gxdh.setWidth(w)
                      gxdh.setHeight(h)
                      gxdh.setTouchable(true)
                      gxdh.setOutsideTouchable(true)
                      gxdh.showAtLocation(fltBtn.Parent,0,0,0)
                      wave.setStartColor(0xFF68AFE5)
                      wave.setCloseColor(0xffffffff)
                      wave.setWaveHeight(10)
                      wave.setVelocity(10)
                      function 进度(i)
                        if i=="完成" then
                          jd.text="100%"
                          wave.setProgress(0)
                          task(1000,function()
                            jd.text="更新完成,\n点击关闭\n长按重启."
                            gxtx.onClick=function()gxdh.dismiss()end
                            gxtx.onLongClick=function()activity.recreate()end
                          end)
                         else
                          jd.text=tointeger(i*99).."%"
                          wave.setProgress(1.02-i)
                        end
                      end
                      thread(function()
                        require"import"
                        import"java.net.URL"
                        local path="/data/data/"..activity.getPackageName().."/工具箱.zip"
                        local ur=URL("https://api.github.com/repos/donothavename/gx/contents/%E5%B7%A5%E5%85%B7%E7%AE%B1.zip")
                        import "java.io.File"
                        file =File(path);
                        local con = ur.openConnection();
                        con.setRequestProperty("Accept","application/vnd.github.VERSION.raw")
                        local co = con.getContentLength();
                        local is = con.getInputStream();
                        local bs = byte[1024]
                        local len,read=0,0
                        import "java.io.FileOutputStream"
                        local wj= FileOutputStream(path);
                        len = is.read(bs)
                        while len~=-1 do
                          wj.write(bs,0,len);
                          read=read+len
                          pcall(call,"进度",read/co)
                          Thread.sleep(50)
                          len=is.read(bs)
                        end
                        wj.close();
                        is.close();
                        import"com.androlua.ZipUtil"
                        ZipUtil.unzip(path,"/data/data/"..activity.getPackageName())
                        call("进度","完成")
                      end)
                    end,
                  },
                },
              },
            },
          },
        },
      }))
      波纹(gbjcdgxbj,0xFFE2E2E2)
      位移动画(bjkp,200,0,0,geth(bjkp),0)
      function 关闭()
        位移动画(bjkp,200,0,0,0,geth(bjkp),function()
          bjbj.setVisibility(8)
        end)
      end
      bjkpsety=0
      bjbj.onTouch=function(v,e)
        a=e.getAction()&255
        if a==MotionEvent.ACTION_DOWN then
          if e.getY()>=h-geth(bjkp) then
            csdjwz=e.getY()
           else
            csdjwz=h+1
          end
         elseif a==MotionEvent.ACTION_MOVE then
          if csdjwz==h+1 then
           elseif csdjwz>e.getY() then
            csdjwz=e.getY()
           else
            bjkpsety=h-geth(bjkp)+e.getY()-csdjwz+10*scale
            bjkp.setY(bjkpsety)
          end
         elseif a==MotionEvent.ACTION_UP then
          if csdjwz==h+1 then
            关闭()
           elseif bjkpsety>=h-0.5*geth(bjkp) then
            关闭()
           else
            bjkp.setY(h-geth(bjkp)+10*scale)
            位移动画(bjkp,150,0,0,bjkpsety-(h-geth(bjkp)+10*scale),0)
          end
        end
        return true
      end
    end
  end
end)