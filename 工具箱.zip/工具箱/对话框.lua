import "android.app.AlertDialog"
import "android.graphics.drawable.ColorDrawable"
local Dialog={}
local n={}
n.we1='1'
n.we2='1'
n.we3='1'
function 对话框()
n.button3=nil
n.button2=nil
n.button1=nil
n.fun1=function()end
n.fun2=function()end
n.fun3=function()end
n.title=nil
n.radius=nil
n.text=nil
buju=nil
return Dialog
end
function n.fun1()
end
function n.fun2()
end
function n.fun3()
end
function n.sz()
end
function Dialog.添加布局(tjbj)
buju=tjbj
return Dialog
end
function 插入布局(bj)
return bj
end
function Dialog.设置标题(text)
  n.title=text
  return Dialog
end
function Dialog.设置消息(text)
  n.text=text
  return Dialog
end
function Dialog.设置积极按钮(text,fun)
  n.button3=text
  if fun then
    n.fun3=fun
  end
  return Dialog
end
function Dialog.设置消极按钮(text,fun)
  n.button1=text
  if fun then
    n.fun1=fun
  end
  return Dialog
end
function Dialog.设置中立按钮(text,fun)
  n.button2=text
  if fun then
    n.fun2=fun
  end
  return Dialog
end
function Dialog.设置圆角(radius)
  n.radius=radius
  return Dialog
end
function Dialog.显示()
local viewlayout={
    LinearLayout,
    gravity="center",
    {
      CardView,
      elevation="5dp",
      {
        LinearLayout,
        orientation="vertical",
        layout_width="85%w",
        backgroundColor=0xFFFFFFFF,
        {
          TextView,
          id="retitle",
          paddingTop="18dp",
          paddingLeft="24dp",
          paddingRight="24dp",
          textSize="20sp",
          text=n.title,
          textColor=0xFF000000,
        },
        {
          ScrollView,
          {
            TextView,
            id="retext",
            paddingTop="5dp",
            paddingLeft="24dp",
            paddingRight="24dp",
            paddingBottom="24dp",
            textSize="18sp",
            textColor=0xFF000000,
            text=n.text,
          },
        },
        {
          LinearLayout,
          id="anniu",
          gravity="right",
          layout_width="fill",
          paddingTop="4.5dp",
          paddingLeft="12.5dp",
          paddingRight="12.5dp",
          paddingBottom="4.5dp",
          orientation="horizontal",
          {
            LinearLayout,
            layout_weight=1,
            layout_height="46dp",
            {
              TextView,
              id="xjan",
              text=n.button1,
              gravity="center",
              layout_height="36dp",
              layout_width="63.5dp",
              textColor=0xFF68AFE5,
              layout_gravity="left|center",
              onClick=function()
                if n.button1 then
                  n.fun1()
                  dhk.dismiss()
                end
              end,
            },
          },
          {
            LinearLayout,
            layout_width="63.5dp",
            layout_height="46dp",
            {
              TextView,
              id="zlan",
              text=n.button2,
              gravity="center",
              layout_width="fill",
              layout_height="36dp",
              layout_gravity="center",
              textColor=0xFF68AFE5,
              onClick=function()
                if n.button2 then
                  n.fun2()
                  dhk.dismiss()
                end
              end,
            },
          },
          {
            LinearLayout,
            layout_width="63.5dp",
            layout_height="46dp",
            {
              TextView,
              id="jjan",
              text=n.button3,
              gravity="center",
              layout_width="fill",
              layout_height="36dp",
              layout_gravity="center",
              textColor=0xFF68AFE5,
              onClick=function()
                if n.button3 then
                  n.fun3()
                  dhk.dismiss()
                end
              end,
            },
          },
        },
      },
    },
  }
  dialog=AlertDialog.Builder(this)
  dhk=dialog.show()
  dhk.setCancelable(true).getWindow().setContentView(loadlayout(viewlayout)).setBackgroundDrawable(ColorDrawable(0x00000000));
  if n.title==nil then retitle.setVisibility(View.GONE)end
  if n.text==nil then retext.setVisibility(View.GONE)end
  if n.button1==nil and n.button2==nil and n.button3==nil then anniu.setVisibility(8)end
  if n.button1 then 波纹方(xjan,0xFFE5F2FA) end
  if n.button2 then 波纹方(zlan,0xFFE5F2FA) end
  if n.button3 then 波纹方(jjan,0xFFE5F2FA) end
  if geth(retext)>0.85*h then seth(retext.Parent,0.8*h) end
end